using UnityEngine;
public class EnumBannerAdSize : MonoBehaviour
{
    public enum VS_AdmobBannerSize
    {
        Banner,
        IABBanner,
        Leaderboard,
        MediumRectangle,
    };

    public enum VS_AdmobBannerPosition
    {
        Bottom,
        BottomLeft,
        BottomRight,
        Center,
        Top,
        TopLeft,
        TopRight
    };
}

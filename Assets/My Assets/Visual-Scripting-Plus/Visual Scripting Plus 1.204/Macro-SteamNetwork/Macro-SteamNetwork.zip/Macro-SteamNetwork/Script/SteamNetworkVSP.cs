using Netcode.Transports.Facepunch;
using Steamworks;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Unity.Netcode;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Rendering.VirtualTexturing;
using Debug = UnityEngine.Debug;
using Lobby = Steamworks.Data.Lobby;

public class SteamNetworkVSP : MonoBehaviour
{
    #region Variable
    [SerializeField]
    private GameObject NetcodeSample;

    public static SteamNetworkVSP Instance { get; private set; } = null;
    private GameObject MacroNetcode ;
    private GameObject MacroSteamworks;
    private bool FriendOnly = false;
    private bool _isHostLastGame = false;
    private string localSteamID = "";
    private NetworkVariableVSP NetcodeSample_Script;
    private string _SubHostId = "-1";
    private string _HostId = "-1";

    public Lobby? CurrentLobby { get; private set; } = null;
    private int _MaxPlayers = 8;
    private string _CurrentLobbyID = "-1";
    private bool isSteamReady = false;
    private bool isLobbyClient = false;
    private bool Setup_LobbyCanHostReconnect = false;
    private string maxLimitNumber = "9999999";
    private int LobbyLimitTime = 60;
    private Dictionary<string, string> ALobbyData;

    private SteamLobbyVSP tempLobbyInfo_ = new SteamLobbyVSP();
    private FacepunchTransport SteamTransport = null;
    #endregion

    #region StartInitial

    public string GetHostID()
    {
        return _HostId;
    }
    public bool isHostCanReconnect()
    {
        return Setup_LobbyCanHostReconnect;
    }
    private string FormatNewStringReplaceVSP(string Original_)
    {
        string newString_ = "";
        string FormatChars = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM0123456789_";
        for (int i = 0; i < Original_.Length; i++)
        {
            string listChar_each = Original_[i].ToString();
            if (FormatChars.IndexOf(listChar_each) >= 0)
            {
                newString_ = newString_ + listChar_each;
            }

        }
        return newString_;
    }

    public void setMaxLimitNumber(int number)
    {
        maxLimitNumber = number.ToString();
    }
    public bool isMeLobbyClient()
    {
        return isLobbyClient;
    }
    public int GetLobbyLimitTime()
    {
        return LobbyLimitTime;
    }
    public void SetLobbyLimitTime(int time_)
    {
        LobbyLimitTime = time_;
    }
    public void SetLobbyFriendOnly(bool Bool)
    {
        FriendOnly = Bool;
    }
    public string GetUserSteamID()
    {
        return localSteamID;
    }
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        DontDestroyOnLoad(gameObject);

        var MacroNetcode_Script = FindObjectOfType<NetcodeVSP>();
        MacroNetcode = MacroNetcode_Script.gameObject;
        
        MacroSteamworks = FindObjectOfType<SteamNetworkVSP>().gameObject;
        SteamTransport = FindObjectOfType<FacepunchTransport>();
    }

    IEnumerator CheckReady() 
    {
        yield return new WaitUntil(()=> NetworkManager.Singleton != null);
        
        NetworkManager.Singleton.NetworkConfig.NetworkTransport = SteamTransport;
        isSteamReady = true;
        localSteamID = SteamClient.SteamId.Value.ToString();
        NetcodeSample_Script = NetcodeSample.GetComponent<NetworkVariableVSP>();
        CustomEvent.Trigger(MacroSteamworks, "OnSteamInitialized_Trigger");
        AddListenCallbacks();
    }

    public bool isSteamInitialized()
    {
        return isSteamReady;
    }
    void Start()
    {
        StartCoroutine(CheckReady());
    }
    public string mySteamID()
    {
        return localSteamID;
    }
    public string GetCurrentLobbyId()
    {
        if (CurrentLobby.HasValue)
        {
            return CurrentLobby.Value.Id.ToString();
        }
        return "-1";
    }
    private void AddListenCallbacks()
    {
        SteamMatchmaking.OnLobbyCreated += OnLobbyCreatedTrigger;
        SteamMatchmaking.OnLobbyEntered += OnLobbyEnteredTrigger;
        SteamMatchmaking.OnLobbyMemberJoined += OnLobbyMemberJoinedTrigger;
        SteamMatchmaking.OnLobbyMemberLeave += OnLobbyMemberLeaveTrigger;
        SteamMatchmaking.OnLobbyInvite += OnLobbyInviteTrigger;
        SteamMatchmaking.OnLobbyGameCreated += OnLobbyGameCreatedTrigger;
        SteamFriends.OnGameLobbyJoinRequested += OnGameLobbyJoinRequestedTrigger;
        NetworkManager.Singleton.OnServerStarted += OnServerStartedTrigger;
        NetworkManager.Singleton.OnClientConnectedCallback += OnClientConnectedCallback;
        NetworkManager.Singleton.OnClientDisconnectCallback += OnClientDisconnectCallback;
    }
    #endregion

    #region MainBody
    
    public void CreateRoom(bool Setup_HostReconnect, string Setup_roomName, int Setup_maxPlayer, string Setup_Password, bool Setup_Private, string gameMode, string extraMode, int Rank, int RankLimit, int Level, int LevelLimit, int extraLimit, string Setup_Region, bool Setup_isLocked)
    {
        try
        {
            if (isSteamReady == false)
            {
                Debug.Log("Steam is not ready yet. Try it again!");
                return;
            }

            if (Setup_roomName != "-1") { Setup_roomName = FormatNewStringReplaceVSP(Setup_roomName); }
            if (Setup_Region != "-1") { Setup_Region = FormatNewStringReplaceVSP(Setup_Region); }
            if (Setup_Password != "-1") { Setup_Password = FormatNewStringReplaceVSP(Setup_Password); }
            if (gameMode != "-1") { gameMode = FormatNewStringReplaceVSP(gameMode); }

            isLobbyClient = false;
            //..
            //.. Add search GameMode, min max Filter Rank Level ...
            string str_RankLimit = RankLimit.ToString();
            string str_LevelLimit = LevelLimit.ToString();

            if (RankLimit == -1)
            {
                str_RankLimit = maxLimitNumber;
            }
            if (LevelLimit == -1)
            {
                str_LevelLimit = maxLimitNumber;
            }

            var lobbyData = new Dictionary<string, string>()
            {
                ["MaxMembers"] = "" + Setup_maxPlayer.ToString(),
                ["LobbyName"] = "-1",
                ["isPrivate"] = Setup_Private.ToString(),
                ["isLocked"] = "" + Setup_isLocked.ToString(),
                ["LobbyPassword"] = "-1",
                ["GameMode"] = "-1",
                ["ExtraMode"] = "-1",
                ["Rank"] = "-1",
                ["RankLimit"] = "-1",
                ["Level"] = "-1",
                ["LevelLimit"] = "-1",
                ["ExtraNumber"] = "-1",
                ["Region"] = "-1",
                ["Members"] = "",
                ["Slots"] = "" + (Setup_maxPlayer - 1).ToString(),
                ["ClientsConnected"] = "0",
                ["CanHostReconnect"] = "" + Setup_HostReconnect.ToString(),
                ["Clients"] = "0"

            };

            if (Setup_Password != "-1")
            {
                if(Setup_Password.Length < 4 )
                {
                    Debug.Log("Password must at least 4 letters.");
                    return;
                }
            }

            if (Setup_roomName != "-1")
            {
                lobbyData["LobbyName"] = Setup_roomName;
            }

            if (gameMode != "-1")
            {
                lobbyData["GameMode"] = gameMode;
            }
            if (extraMode != "-1")
            {
                lobbyData["ExtraMode"] = extraMode;
            }
            if (Setup_Region != "-1")
            {
                lobbyData["Region"] = Setup_Region;
            }
            if (Rank != -1)
            {
                lobbyData["Rank"] = Rank.ToString();
                lobbyData["RankLimit"] = str_RankLimit;
            }
            if (Level != -1)
            {
                lobbyData["Level"] = Level.ToString();
                lobbyData["LevelLimit"] = str_LevelLimit;
            }
            if (extraLimit != -1)
            {
                lobbyData["ExtraLimit"] = extraLimit.ToString();
            }
            //.. END Add search GameMode, min max Filter Rank Level ...
            //..
            //..

            // Create a new lobby


            if (Setup_Password != "-1")
            {
                lobbyData["LobbyPassword"] = Setup_Password;
            }

            ALobbyData = lobbyData;
            
            HostLobby(Setup_maxPlayer, false);
        }
        catch (Exception ex)
        {
            Debug.Log("Create Lobby error: \n" + ex.ToString());
            CustomEvent.Trigger(MacroSteamworks, "OnLobbyCreated_Failed");
        }
    }

    public async void SearchRoom(bool Setup_SortNew, string Setup_RoomName, int Setup_TotalResult, string Setup_GameMode, string Setup_ExtraMode, string Setup_Rank, string Setup_Level, string Setup_ExtraLimit, string Setup_Region, bool Setup_Lock)
    {
        try
        {
            if (isSteamReady == false)
            {
                Debug.Log("Steam is not ready yet. Try it again!");
                return;
            }

            Lobby[] lobbies = await SteamMatchmaking.LobbyList.WithSlotsAvailable(1).RequestAsync();
            List<string> AvailableLobbiesId = new List<string>();
            List<string> AvailableLobbiesName = new List<string>();
            List<SteamLobbyVSP> AvailableLobbies = new List<SteamLobbyVSP>();

            
            foreach (Lobby lobby in lobbies)
            {
                bool found_ = false;
                bool exit_ = false;
                
                var Data_isPrivate = lobby.GetData("isPrivate");
                if (Data_isPrivate == "True")
                {
                    exit_ = true;
                }

                
                var Data_isLocked = lobby.GetData("isLocked");
                if (Data_isLocked != Setup_Lock.ToString())
                {
                    exit_ = true;
                }

                var Data_GameMode = lobby.GetData("GameMode");
                if (Setup_GameMode != "-1")
                {
                    if (Data_GameMode != Setup_GameMode)
                    {
                        exit_ = true;
                    }
                }

                var Data_RoomName = lobby.GetData("LobbyName");
                if (Setup_RoomName != "-1")
                {
                    
                    if (Data_RoomName != Setup_RoomName)
                    {
                        exit_ = true;
                    }
                }

                var Data_Region = lobby.GetData("Region");
                if (Setup_Region != "-1")
                {
                    if (Data_Region != Setup_Region)
                    {
                        exit_ = true;
                    }
                }

                var Data_ExtraMode = lobby.GetData("ExtraMode");
                if (exit_ == false && Setup_ExtraMode != "-1")
                {
                    if (Data_ExtraMode != Setup_ExtraMode)
                    {
                        exit_ = true;
                    }
                }

                var Data_Rank = lobby.GetData("Rank");
                var Data_RankLimit = lobby.GetData("RankLimit");
                if (exit_ == false && Setup_Rank != "-1")
                {
                    if (int.Parse(Setup_Rank) < int.Parse(Data_Rank) || int.Parse(Setup_Rank) > int.Parse(Data_RankLimit))
                    {
                        exit_ = true;
                    }
                }

                var Data_Level = lobby.GetData("Level");
                var Data_LevelLimit = lobby.GetData("LevelLimit");
                if (exit_ == false && Setup_Level != "-1")
                {
                    if (int.Parse(Setup_Level) < int.Parse(Data_Level) || int.Parse(Setup_Level) > int.Parse(Data_LevelLimit))
                    {
                        exit_ = true;
                    }
                }

                var Data_ExtraNumber = lobby.GetData("ExtraNumber");
                if (exit_ == false && Setup_ExtraLimit != "-1")
                {
                    if (int.Parse(Setup_ExtraLimit) > int.Parse(Data_ExtraNumber))
                    {
                        exit_ = true;
                    }
                }

                if (exit_ == false)
                {
                    found_ = true;
                }


                int found_Count = 0;
                if (found_ == true)
                {

                    SteamLobbyVSP newLobby = new SteamLobbyVSP();
                    newLobby.MaxPlayers = lobby.MaxMembers;
                    newLobby.ID = lobby.Id.ToString();

                    newLobby.Name = lobby.GetData("LobbyName");
                    newLobby.HostId = lobby.GetData("HostId");
                    newLobby.SubHostId = lobby.GetData("SubHostId");
                    newLobby.isPrivate = lobby.GetData("isPrivate");
                    newLobby.isLocked = Data_isLocked;
                    newLobby.Password = lobby.GetData("LobbyPassword");
                    newLobby.CanHostReconnect = lobby.GetData("CanHostReconnect");

                    newLobby.Search_GameMode = lobby.GetData("GameMode");
                    newLobby.Search_ExtraMode = lobby.GetData("ExtraMode");
                    newLobby.Search_RankMin = lobby.GetData("Rank");
                    newLobby.Search_RankMax = lobby.GetData("RankLimit");
                    newLobby.Search_LevelMin = lobby.GetData("Level");
                    newLobby.Search_LevelMax = lobby.GetData("LevelLimit");
                    newLobby.Search_ExtraNumber = lobby.GetData("ExtraNumber");
                    newLobby.Search_Region = lobby.GetData("Region");

                    newLobby.Members = ConvertListMembersID(lobby.GetData("Members"));
                    newLobby.Clients = ConvertListClientsID(lobby.GetData("Clients"));
                    newLobby.ClientsConnected = ConvertListClientsConnected(lobby.GetData("ClientsConnected"));

                    found_Count++;
                    if (found_Count <= Setup_TotalResult)
                    {
                        AvailableLobbies.Add(newLobby);
                    }
                    else
                    {
                        break;
                    }

                    

                }

            }

            if (AvailableLobbies.Count > 0)
            {
                //var sortedList = AvailableLobbies.OrderBy(myLobby=> myLobby.ID).ToList();
                //AvailableLobbies = sortedList;
                for (int i = 0; i < AvailableLobbies.Count; i++)
                {
                    var tempID = AvailableLobbies[i].ID;
                    var tempLobby_ = AvailableLobbies[i];
                    for (int j = i + 1; j < AvailableLobbies.Count; j++)
                    {
                        var currentID = AvailableLobbies[j].ID;
                        var currentLobby_ = AvailableLobbies[j];

                        if (Setup_SortNew == true && currentID.CompareTo(tempID) > 0)
                        {
                            AvailableLobbies[j] = tempLobby_;
                            AvailableLobbies[i] = currentLobby_;
                            tempLobby_ = currentLobby_;
                            tempID = currentLobby_.ID;
                        }
                        if (Setup_SortNew == false && currentID.CompareTo(tempID) < 0)
                        {
                            AvailableLobbies[j] = tempLobby_;
                            AvailableLobbies[i] = currentLobby_;
                            tempLobby_ = currentLobby_;
                            tempID = currentLobby_.ID;
                        }
                    }
                }


            }

            CustomEvent.Trigger(MacroSteamworks, "SearchRoom_Ok_Trigger", AvailableLobbies);
        }
        catch (Exception ex)
        {
            Debug.Log("Search Room error: \n" + ex.ToString());
        }
    }

    private async void HostLobby(int MaxPlayer_, bool FriendOnly_)
    {
        try
        {
            _MaxPlayers = MaxPlayer_;
            FriendOnly = FriendOnly_;
            
            
            
            await SteamMatchmaking.CreateLobbyAsync(_MaxPlayers);
        }
        catch (Exception ex)
        {
            Debug.Log("Host Lobby error: \n" + ex.ToString());
            CustomEvent.Trigger(MacroSteamworks, "OnLobbyCreated_Failed");
        }
    }
    private void OnLobbyCreatedTrigger(Result result, Lobby lobby)
    {
        
        if (result == Result.OK)
        {
            NetworkManager.Singleton.StartHost(); //Start Host
            _isHostLastGame = true;
            //Set Lobby Filter Data
            var Lobby_LobbyName = ALobbyData["LobbyName"];
            var Lobby_isPrivate = ALobbyData["isPrivate"];
            var Lobby_isLocked = ALobbyData["isLocked"];
            var Lobby_LobbyPassword = ALobbyData["LobbyPassword"];
            var Lobby_GameMode = ALobbyData["GameMode"];
            var Lobby_ExtraMode = ALobbyData["ExtraMode"];
            var Lobby_Rank = ALobbyData["Rank"];
            var Lobby_RankLimit = ALobbyData["RankLimit"];
            var Lobby_Level = ALobbyData["Level"];
            var Lobby_LevelLimit = ALobbyData["LevelLimit"];
            var Lobby_ExtraNumber = ALobbyData["ExtraNumber"];
            var Lobby_Region = ALobbyData["Region"];
            var Lobby_CanHostReconnect = ALobbyData["CanHostReconnect"];
            var Lobby_MaxPlayer = lobby.MaxMembers;

            if (Lobby_LobbyName != "-1")
            {
                lobby.SetData("LobbyName", Lobby_LobbyName);
            }
            else
            {
                lobby.SetData("LobbyName", "-1");
            }

            _HostId = localSteamID;
            lobby.SetJoinable(true);
            lobby.SetPublic();

            _CurrentLobbyID = lobby.Id.Value.ToString();
            lobby.SetData("MaxMembers", Lobby_MaxPlayer.ToString());
            lobby.SetData("HostId", localSteamID);
            lobby.SetData("SubHostId", "-1");
            lobby.SetData("ID", _CurrentLobbyID);
            lobby.SetData("isPrivate", Lobby_isPrivate);
            lobby.SetData("isLocked", Lobby_isLocked);
            lobby.SetData("LobbyPassword", Lobby_LobbyPassword);
            lobby.SetData("GameMode", Lobby_GameMode);
            lobby.SetData("Region", Lobby_Region);
            lobby.SetData("ExtraMode", Lobby_ExtraMode);
            lobby.SetData("Rank", Lobby_Rank);
            lobby.SetData("RankLimit", Lobby_RankLimit);
            lobby.SetData("Level", Lobby_Level);
            lobby.SetData("LevelLimit", Lobby_LevelLimit);
            lobby.SetData("ExtraNumber", Lobby_ExtraNumber);
            lobby.SetData("Members", ""+localSteamID);
            lobby.SetData("Clients","0");
            lobby.SetData("Slots", "" + (Lobby_MaxPlayer - 1).ToString());

            lobby.SetData("CanHostReconnect", Lobby_CanHostReconnect);
            lobby.SetData("ClientsConnected", "0");

            CurrentLobby = lobby;

            CustomEvent.Trigger(MacroSteamworks, "OnLobbyCreated_Trigger", lobby.Id.ToString(), Lobby_LobbyName, Lobby_isPrivate, Lobby_LobbyPassword);
        }
        else
        {
            CustomEvent.Trigger(MacroSteamworks, "OnLobbyCreated_Failed");
        }

    }
    public async void JoinLobbyWithID(string ID_)
    {
        try
        {
            if (isSteamReady == false)
            {
                Debug.Log("Steam is not ready yet. Try it again!");
                return;
            }

            isLobbyClient = false;
            ulong ID;
            if (!ulong.TryParse(ID_, out ID))
            {
                return;
            }
            
            CurrentLobby = await SteamMatchmaking.JoinLobbyAsync(ID);
            Debug.Log("Joined Lobby with ID:" + ID);
        }
        catch (Exception ex)
        {
            Debug.Log("Join Lobby with ID error: \n"+ ex.ToString());
            CustomEvent.Trigger(MacroSteamworks, "OnJoinLobby_Failed");
        }
        
    }
    
    //Client join in lobby
    private void OnLobbyEnteredTrigger(Lobby lobby)
    {
        try
        {
            CurrentLobby = lobby;
            
            if (NetworkManager.Singleton.IsHost)
            {
                CustomEvent.Trigger(MacroSteamworks, "OnLobbyEntered_Hearting", lobby.Id.ToString());
                CustomEvent.Trigger(MacroSteamworks, "OnLobbyEntered_Trigger", lobby.Id.ToString(), lobby.MemberCount);
                return;
            }


            SteamTransport.targetSteamId = lobby.Owner.Id;
            _HostId = lobby.Owner.Id.ToString();
            CurrentLobby = lobby;
            

            isLobbyClient = true;
            Debug.Log("Starting Client....");
            NetworkManager.Singleton.StartClient();
            CustomEvent.Trigger(MacroSteamworks, "OnLobbyEntered_Hearting", lobby.Id.ToString());
            CustomEvent.Trigger(MacroSteamworks, "OnLobbyEntered_Trigger", lobby.Id.ToString(), lobby.MemberCount);
            CustomEvent.Trigger(MacroSteamworks, "OnJoinLobby_Success");
        }
        catch (Exception e)
        {
            Debug.Log("OnLobbyEntered Error: \n" + e.ToString());
            CustomEvent.Trigger(MacroSteamworks, "OnJoinLobby_Failed");
        }

    }

    //trigger on Host
    private void OnLobbyMemberJoinedTrigger(Lobby lobby, Friend friend)
    {
        //Debug.Log("OnLobbyMemberJoined ");
        if(NetworkManager.Singleton.IsHost)
        {
            //UpdateMemberIdInLobby();
        }
        
        CustomEvent.Trigger(MacroSteamworks, "OnLobbyMemberJoined_Trigger", friend.Id.Value.ToString(), friend.Name, lobby.Id.ToString(), lobby.MemberCount);

    }

    #endregion


    #region Reconnecting
    public void BecomeNewHost(string newLobbyID_, int Setup_LobbyMaxPlayer)
    {
        var Setup_LobbyName_ = "" + newLobbyID_;
        CustomEvent.Trigger(MacroSteamworks, "BecomeNewHost_CreateLobby", Setup_LobbyName_, Setup_LobbyMaxPlayer);
    }

    #endregion

    #region UpdateClientInfo


    public void AskingUpdateClientIdInALobby(string ClientID,string ClientSteamID)
    {
        NetcodeSample_Script.SteamUpdateClientPrepare(ClientID, ClientSteamID);
    }

    public void HostUpdateClientIdInLobby(string ClientID, string ClientSteamID)
    {
        try
        {
            //Lobby myLobby = CurrentLobby.Value;
            var myLobby = CurrentLobby.Value;
            
            string AllClientsID_String = myLobby.GetData("Clients");
            var AllClientsID = ConvertListClientsID(AllClientsID_String);
            string AllClients_new = AllClientsID_String;

            string AllMembers_String = myLobby.GetData("Members");
            var AllMembers = ConvertListMembersID(AllMembers_String);
            var AllMembers_Copy = AllMembers;
            string AllMembers_new = AllMembers_String;

            string AllClientsConnected_String = myLobby.GetData("ClientsConnected");
            var AllClientsConnected = ConvertListClientsConnected(AllClientsConnected_String);
            string AllClientsConnected_new = AllClientsConnected_String;

            int Slots_ = int.Parse(myLobby.GetData("Slots"));
            
            bool update_yes = false;
            if (AllMembers.Count > 0)
            {
                bool existed = false;


                foreach (var memberDataId in AllMembers)
                {
                    if (memberDataId == ClientSteamID)
                    {
                        existed = true;

                        break;
                    }
                }

                if (existed == false)
                {
                    update_yes = true;

                    AllMembers_new = AllMembers_String + "," + ClientSteamID;
                    AllClientsConnected_new = AllClientsConnected_new + "," + "1";
                    Slots_ = Slots_ - 1;
                    if (Slots_ < 0)
                    {
                        Slots_ = 0;
                    }
                }

                if (update_yes == true)
                {
                    CurrentLobby.Value.SetData("Members", AllMembers_new);
                    CurrentLobby.Value.SetData("ClientsConnected", AllClientsConnected_new);
                    CurrentLobby.Value.SetData("Slots", Slots_.ToString());

                }
            }
            else
            {
                return;
            }

            
            AllMembers = ConvertListMembersID(AllMembers_new);
            AllMembers_new = AllMembers_String;

            int index_ = -1;

            
            foreach (var member in AllMembers)
            {

                index_++;
                if (member == ClientSteamID)
                {
                    break;
                }
            }

            if (index_ > 0)
            {
                if (index_ >= AllClientsID.Count)
                {
                    AllClients_new = AllClientsID_String + "," + ClientID;
                }
                else
                {
                    AllClientsID[index_] = ClientID;
                    string AllClients_new_new = "0";

                    int j = -1;
                    foreach (var clientid_temp in AllClientsID)
                    {
                        j++;
                        if (j > 0)
                        {
                            AllClients_new_new = AllClients_new_new + "," + clientid_temp;
                        }

                    }
                    AllClients_new = AllClients_new_new;
                }

                CurrentLobby.Value.SetData("Clients", AllClients_new);
            }

            CheckUpdateSubHost();
            LobbyUpdateToAllClient();
        }

        catch (Exception e)
        {
            Debug.Log("Host Update Client Id error: \n" + e.ToString());
        }
    }
    public void RemoveMemberIdInLobby(string friendSteamID)
    {
        // If Client MemberID not in the Lobby, add it into
        try
        {
            Lobby myLobby = CurrentLobby.Value;


            string AllClientsID_String = myLobby.GetData("Clients");
            var AllClientsID = ConvertListClientsID(AllClientsID_String);
            string AllClients_new = AllClientsID_String;

            string AllMembers_String = myLobby.GetData("Members");
            var AllMembers = ConvertListMembersID(AllMembers_String);
            string AllMembers_new = AllMembers_String;

            string AllClientsConnected_String = myLobby.GetData("ClientsConnected");
            var AllClientsConnected = ConvertListClientsConnected(AllClientsConnected_String);
            string AllClientsConnected_new = AllClientsConnected_String;

            int Slots_ = int.Parse(myLobby.GetData("Slots"));
            int MaxPlayer_Value = myLobby.MaxMembers;

            bool foundID_ = false;
            int index_ = -1;
            if (AllMembers.Count > 0)
            {
                foreach (var memberDataId in AllMembers)
                {
                    index_++;
                    if (memberDataId == friendSteamID)
                    {
                        foundID_ = true;
                        break;
                    }
                }


                if (foundID_ == true)
                {
                    AllMembers.RemoveAt(index_);
                    AllClientsID.RemoveAt(index_);
                    AllClientsConnected.RemoveAt(index_); // ..

                    Slots_ = Slots_ + 1;
                    if (Slots_ > MaxPlayer_Value)
                    {
                        Slots_ = MaxPlayer_Value;
                    }

                    string new_AllMembers = "";
                    string new_AllClients = "";
                    string new_AllClientsConnected = "";

                    int i = 0;
                    foreach (var memberItem_ in AllMembers)
                    {
                        if (i > 0)
                        {
                            new_AllMembers = new_AllMembers + "," + memberItem_.ToString();
                        }
                        else
                        {
                            new_AllMembers = memberItem_.ToString();
                        }
                        i++;
                    }

                    i = 0;
                    foreach (var clientItem_ in AllClientsID)
                    {
                        if (i > 0)
                        {
                            new_AllClients = new_AllClients + "," + clientItem_.ToString();
                        }
                        else
                        {
                            new_AllClients = clientItem_.ToString();
                        }
                        i++;
                    }

                    i = 0;
                    foreach (var clientItem_Connected in AllClientsConnected)
                    {
                        if (i > 0)
                        {
                            new_AllClientsConnected = new_AllClientsConnected + "," + clientItem_Connected.ToString();
                        }
                        else
                        {
                            new_AllClientsConnected = clientItem_Connected.ToString();
                        }
                        i++;
                    }

                    CurrentLobby.Value.SetData("Members", new_AllMembers);
                    CurrentLobby.Value.SetData("Clients", new_AllClients);
                    CurrentLobby.Value.SetData("ClientsConnected", new_AllClientsConnected);
                    CurrentLobby.Value.SetData("Slots", Slots_.ToString());

                }
            }
            else
            {
                return;
            }


            CheckUpdateSubHost();
            LobbyUpdateToAllClient();
        }
        catch (Exception e)
        {
            Debug.Log("Remove Member ID in Lobby Error: \n" + e.ToString());
        }
    }
    private void CheckUpdateSubHost()
    {
        
        var AllClientsConnected = ConvertListClientsConnected(CurrentLobby.Value.GetData("ClientsConnected"));
        var AllMembers = ConvertListClientsConnected(CurrentLobby.Value.GetData("Members"));

        bool found_ = false;
        for (int i = 0; i < AllClientsConnected.Count; i++)
        {
            var tempID_ = AllClientsConnected[i];
            if (i > 0 && tempID_ == "1")
            {
                found_ = true;
                var MemberSteamID_ = AllMembers[i];
                if (_SubHostId != MemberSteamID_)
                {
                    _SubHostId = MemberSteamID_;
                    CurrentLobby.Value.SetData("SubHostId", _SubHostId);
                }
                
                break;
            }
        }
        if (found_ == false)
        {
            _SubHostId = "-1";
            CurrentLobby.Value.SetData("SubHostId", _SubHostId);
        }
    }
    
    private void LobbyUpdateToAllClient()
    {
        var LobbyData_ = CurrentLobby.Value;
        string Info_ = "=" + LobbyData_.GetData("Members");
        Info_ = Info_ + ":" + LobbyData_.GetData("Clients");
        Info_ = Info_ + "!" + _SubHostId;
        Info_ = Info_ + "#" + LobbyData_.GetData("isLocked"); ;

        CustomEvent.Trigger(MacroSteamworks, "LobbyUpdateToAllClient_Trigger", Info_);
        SaveCurrentLoby();
    }

    
    public void onClientReceivedLobbyUpdateInfo(string Members_, string Clients_, string SubHost_, string Locked_)
    {
        try
        {
            if (isSteamReady == false || CurrentLobby.HasValue == false)
            {
                Debug.Log("Not ready yet!");
                return;
            }

            var Data_Member_ = ConvertListMembersID(Members_);
            int Slots_ = CurrentLobby.Value.MaxMembers - Data_Member_.Count;

            CurrentLobby.Value.SetData("Members", Members_);
            CurrentLobby.Value.SetData("Clients", Clients_);
            CurrentLobby.Value.SetData("Slots", Slots_.ToString());
            CurrentLobby.Value.SetData("SubHostId", SubHost_);
            CurrentLobby.Value.SetData("isLocked", Locked_);
            SaveCurrentLoby();
        }
        catch (Exception ex) {
            Debug.Log("Update Lobby : " + ex.ToString());
        }
    }

    public void SaveCurrentLoby()
    {
        CustomEvent.Trigger(MacroSteamworks, "SaveCurrentLoby_Trigger", CurrentLobby.Value.Id.ToString(), CurrentLobby.Value.GetData("SubHostId").ToString(), CurrentLobby.Value.GetData("CanHostReconnect").ToString(), _isHostLastGame.ToString(), CurrentLobby.Value.GetData("isLocked").ToString());
    }

    public void ResetCurrentLobby()
    {
        Lobby lobby = new Lobby();
        CurrentLobby = lobby;
    }

    public void LockALobby(string ID_, bool Bool_)
    {
        if (isSteamReady == false || CurrentLobby.HasValue == false)
        {
            return;
        }

        CurrentLobby.Value.SetData("isLocked", Bool_.ToString());
        LobbyUpdateToAllClient();
    }


    #endregion

    #region GetLobbyInfo

    public SteamLobbyVSP GetCurrentLobbyInfo()
    {
        SteamLobbyVSP myLobby = new SteamLobbyVSP();
        try
        {

            if (isSteamReady == false || CurrentLobby.HasValue == false)
            {
                //Debug.Log("Steam is not ready yet. Try it again!");
                myLobby.Name = "-1";
                myLobby.MaxPlayers = 0;
                myLobby.ID = "-1";
                myLobby.Password = "-1";
                myLobby.HostId = "-1";
                myLobby.SubHostId = "-1";
                myLobby.isPrivate = "False";
                myLobby.isLocked = "False";
                myLobby.Search_GameMode = "-1";
                myLobby.Search_ExtraMode = "-1";
                myLobby.Search_RankMin = "-1";
                myLobby.Search_RankMax = "-1";
                myLobby.Search_LevelMin = "-1";
                myLobby.Search_LevelMax = "-1";
                myLobby.Search_ExtraNumber = "-1";
                myLobby.Search_Region = "-1";
                myLobby.Slots = "0";
                myLobby.CanHostReconnect = "False";


                myLobby.Members = ConvertListMembersID("0");
                myLobby.Clients = ConvertListClientsID("0");
                myLobby.ClientsConnected = ConvertListClientsConnected("0");
                myLobby.SteamUsers = null;
                return myLobby;
            }

            myLobby.Name = CurrentLobby.Value.GetData("LobbyName");
            myLobby.MaxPlayers = CurrentLobby.Value.MaxMembers;
            myLobby.ID = CurrentLobby.Value.Id.ToString();
            myLobby.Password = CurrentLobby.Value.GetData("LobbyPassword");
            myLobby.HostId = CurrentLobby.Value.GetData("HostId");
            myLobby.SubHostId = CurrentLobby.Value.GetData("SubHostId");
            myLobby.isPrivate = CurrentLobby.Value.GetData("isPrivate");
            myLobby.isLocked = CurrentLobby.Value.GetData("isLocked");
            myLobby.Search_GameMode = CurrentLobby.Value.GetData("GameMode");
            myLobby.Search_ExtraMode = CurrentLobby.Value.GetData("ExtraMode");
            myLobby.Search_RankMin = CurrentLobby.Value.GetData("Rank");
            myLobby.Search_RankMax = CurrentLobby.Value.GetData("RankLimit");
            myLobby.Search_LevelMin = CurrentLobby.Value.GetData("Level");
            myLobby.Search_LevelMax = CurrentLobby.Value.GetData("LevelLimit");
            myLobby.Search_ExtraNumber = CurrentLobby.Value.GetData("ExtraNumber");
            myLobby.Search_Region = CurrentLobby.Value.GetData("Region");
            myLobby.Slots = CurrentLobby.Value.GetData("Slots");
            myLobby.CanHostReconnect = CurrentLobby.Value.GetData("CanHostReconnect");

            var ListMembers_ = CurrentLobby.Value.GetData("Members");
            var ListClients_ = CurrentLobby.Value.GetData("Clients");
            var ListClientsConnected_ = CurrentLobby.Value.GetData("ClientsConnected");
            myLobby.Members = ConvertListMembersID(ListMembers_);
            myLobby.Clients = ConvertListClientsID(ListClients_);
            myLobby.ClientsConnected = ConvertListClientsConnected(ListClientsConnected_);
            myLobby.SteamUsers = ConvertListSteamUsers();

            return myLobby;
        }
        catch
        {
            //Debug.Log("Get Lobby With ID Error: \n" + e.ToString());
            return myLobby;
        }

    }
    public List<string> ConvertListMembersID(string String_Value)
    {
        
        List<string> myMembers = new List<string>();
        int count = Regex.Matches(String_Value, ",").Count + 1;
        string m_String = String_Value;
        int check_ = -1;

        for (int i = 0; i < count; i++)
        {
            check_ = m_String.IndexOf(",");
            if (check_ >= 0)
            {
                var aMemberID = m_String.Substring(0, check_);
                myMembers.Add(aMemberID);

                aMemberID = aMemberID + ",";
                m_String = m_String.Replace(aMemberID,"");
            }
            else
            {
                myMembers.Add(m_String);
                break;
            }
        }
        return myMembers;
    }
    public List<string> ConvertListClientsID(string String_Value)
    {

        List<string> myMembers = new List<string>();
        int count = Regex.Matches(String_Value, ",").Count + 1;
        string m_String = String_Value;
        int check_ = -1;

        for (int i = 0; i < count; i++)
        {
            check_ = m_String.IndexOf(",");
            if (check_ >= 0)
            {
                var aMemberID = m_String.Substring(0, check_);
                myMembers.Add(aMemberID);

                aMemberID = aMemberID + ",";
                m_String = m_String.Replace(aMemberID, "");
            }
            else
            {
                myMembers.Add(m_String);
                break;
            }
        }
        return myMembers;
    }
    public List<string> ConvertListClientsConnected(string String_Value)
    {

        List<string> myMembers = new List<string>();
        int count = Regex.Matches(String_Value, ",").Count + 1;
        string m_String = String_Value;
        int check_ = -1;

        for (int i = 0; i < count; i++)
        {
            check_ = m_String.IndexOf(",");
            if (check_ >= 0)
            {
                var aMemberID = m_String.Substring(0, check_);
                myMembers.Add(aMemberID);

                aMemberID = aMemberID + ",";
                m_String = m_String.Replace(aMemberID, "");
            }
            else
            {
                myMembers.Add(m_String);
                break;
            }
        }
        return myMembers;
    }

    private List<SteamUserVSP> ConvertListSteamUsers()
    {

        List<SteamUserVSP> SteamUsers_ = new List<SteamUserVSP>();
        var ListMembers_ = CurrentLobby.Value.Members;
        SteamUserVSP mySteam = new SteamUserVSP();

        foreach (var member in ListMembers_)
        {
            mySteam.Steam_Id = member.Id.ToString();
            mySteam.Steam_Name = member.Name;
            mySteam.Steam_Level = member.SteamLevel;
            mySteam.Steam_IsMe = member.IsMe;
            mySteam.Steam_IsFriend = member.IsFriend;
            mySteam.Steam_IsOnline = member.IsOnline;

            SteamUsers_.Add(mySteam);
        }

        return SteamUsers_;
    }

    public SteamUserVSP GetSteamMemberInfo(string SteamID_)
    {
        SteamUserVSP mySteam = new SteamUserVSP();
        if (CurrentLobby.HasValue == false)
        {
            return mySteam;
        }
        Lobby myLobby = CurrentLobby.Value;
        
        foreach (var member in myLobby.Members)
        {
            if (member.Id.Value.ToString() == SteamID_)
            {
                mySteam.Steam_Id = SteamID_;
                mySteam.Steam_Name = member.Name;
                mySteam.Steam_Level = member.SteamLevel;

                mySteam.Steam_IsMe = member.IsMe;
                mySteam.Steam_IsFriend = member.IsFriend;
                mySteam.Steam_IsOnline = member.IsOnline;
                break;
            }
        }
        return mySteam;
    }
    #endregion

    #region Network_Callbacks
    private void OnClientConnectedCallback(ulong clientId)
    {
        //Debug.Log("Client is connected , clientId=" + clientId);
        //recentJoinedClient = clientId;
        string clientId_String = clientId.ToString();
        //UpdateClientIdInALobby(ClientID);
        
        CustomEvent.Trigger(MacroSteamworks, "OnClientConnectedTrigger", clientId_String);
    }
    private void OnClientDisconnectCallback(ulong clientId)
    {
        //Debug.Log("Client is disconnected , clientId=" + clientId);
        string clientId_String = clientId.ToString();
        CustomEvent.Trigger(MacroSteamworks, "OnClientDisConnectedTrigger", clientId_String);

        
    }
    private void OnServerStartedTrigger()
    {
        Debug.Log("Server has started!", this);
    }
    #endregion

    #region Steam_Callbacks
    private void OnGameLobbyJoinRequestedTrigger(Lobby lobby, SteamId id)
    {
        Debug.Log("OnGameLobbyJoinRequested ");
    }

    private void OnLobbyGameCreatedTrigger(Lobby lobby, uint ip, ushort port, SteamId id)
    {
        Debug.Log("OnLobbyGameCreated ");
    }
    private void OnLobbyInviteTrigger(Friend friend, Lobby lobby)
    {
        Debug.Log("You got an invite from " + friend.Name, this);
        CustomEvent.Trigger(MacroSteamworks, "OnLobbyInvited_Trigger", friend.Name);
    }

    private void OnLobbyMemberLeaveTrigger(Lobby lobby, Friend friend)
    {
        //Debug.Log("OnLobbyMemberLeave ");
        CustomEvent.Trigger(MacroSteamworks, "OnLobbyMemberLeave_Trigger", friend.Id.Value.ToString(), friend.Name, lobby.Id.ToString(), lobby.MemberCount);
    }
    
    #endregion

    #region End_Leave_Quit_Lobby
    public void LeaveLobby()
    {
        Disconnect();
    }
    private void OnApplicationQuit()
    {
        Disconnect();
    }
    public void Disconnect()
    {
        //CurrentLobby?.Leave();
        CustomEvent.Trigger(MacroSteamworks, "OnLobbyEntered_Hearting_Stop");
        if (CurrentLobby.HasValue)
        {
            CurrentLobby.Value.Leave();
        }

        if (NetworkManager.Singleton == null)
        {
            return;
        }


        NetworkManager.Singleton.Shutdown();
    }

    private void DestroyCallbacks()
    {
        isLobbyClient = false;
        SteamMatchmaking.OnLobbyCreated -= OnLobbyCreatedTrigger;
        SteamMatchmaking.OnLobbyEntered -= OnLobbyEnteredTrigger;
        SteamMatchmaking.OnLobbyMemberJoined -= OnLobbyMemberJoinedTrigger;
        SteamMatchmaking.OnLobbyMemberLeave -= OnLobbyMemberLeaveTrigger;
        SteamMatchmaking.OnLobbyInvite -= OnLobbyInviteTrigger;
        SteamMatchmaking.OnLobbyGameCreated -= OnLobbyGameCreatedTrigger;
        SteamFriends.OnGameLobbyJoinRequested -= OnGameLobbyJoinRequestedTrigger;
        if (NetworkManager.Singleton == null)
        {
            return;
        }
        NetworkManager.Singleton.OnServerStarted -= OnServerStartedTrigger;
        NetworkManager.Singleton.OnClientConnectedCallback -= OnClientConnectedCallback;
        NetworkManager.Singleton.OnClientDisconnectCallback -= OnClientDisconnectCallback;
    }
    private void OnDestroy()
    {
        DestroyCallbacks();
    }
    #endregion

    
}

public struct SteamLobbyVSP
{
    public int MaxPlayers;
    public string Slots;
    public string ID;
    public string Name;
    public string Password;
    public string HostId;
    public string SubHostId;
    public string isPrivate;
    public string CanHostReconnect;
    public string Search_GameMode;
    public string Search_ExtraMode;
    public string Search_RankMin;
    public string Search_RankMax;
    public string Search_LevelMin;
    public string Search_LevelMax;
    public string Search_ExtraNumber;
    public string Search_Region;
    public string isLocked;
    public List<string> Members;
    public List<string> Clients;
    public List<string> ClientsConnected;
    public List<SteamUserVSP> SteamUsers;
}

public struct SteamUserVSP
{
    public string Steam_Id;
    public string Steam_Name;
    public int Steam_Level;

    public bool Steam_IsMe;
    public bool Steam_IsOnline;
    public bool Steam_IsFriend;
}
using Unity.Netcode;
using UnityEngine;

public enum EnumVariableTypeNetworkVSP
{
    STRING,
    FLOAT,
    INT,
    BOOL,
    VECTOR2,
    VECTOR3,
    VECTOR4,
    QUATERNION,
    COLOR,
    RAY,
    RAY2D
};
public struct ClientList_VSP
{
    public ulong ClientID;
    public GameObject PlayerObject;
}

public struct MyNetString_VSP : INetworkSerializable
{
    public string Value;

    // INetworkSerializable
    public void NetworkSerialize<T>(BufferSerializer<T> serializer) where T : IReaderWriter
    {
        serializer.SerializeValue(ref Value);
    }

    public override string ToString()
    {
        return Value.ToString();
    }

    public static implicit operator string(MyNetString_VSP s) => s.ToString();
    public static implicit operator MyNetString_VSP(string s) => new MyNetString_VSP() { Value = new string(s) };

    // ~INetworkSerializable
}
using System.Collections.Generic;

public struct LobbyInfo_VSP
{
    public string Id; //..
    public string HostId; //..
    public string LobbyCode; //..
    public int MaxPlayers; //..
    public bool IsPrivate; //..
    public List<string> Members;
    public List<string> Clients;
    public List<string> ClientsConnected; // to check what Client is currently connected when Lobby is Locked

    public int AvailableSlots; //..
    public string LobbyPassword;
    public bool IsLocked; //..
    public string Name; //..
    public bool CanHostReconnect; //..
    public string Region;
    public string GameMode;
    public string ExtraMode;
    public string LevelMin;
    public string LevelMax;
    public string RankMin;
    public string RankMax;
    public string ExtraNumber;
    
}

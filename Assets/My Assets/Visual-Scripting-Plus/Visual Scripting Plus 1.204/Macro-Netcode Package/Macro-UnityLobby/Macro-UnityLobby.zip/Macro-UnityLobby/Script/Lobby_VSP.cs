using System.Threading.Tasks;
using System;
using Unity.Netcode.Transports.UTP;
using Unity.Services.Authentication;
using Unity.Services.Core;
using Unity.Services.Lobbies;
using Unity.Services.Lobbies.Models;
using UnityEngine;
using System.Collections.Generic;
using Unity.Netcode;
using System.Collections;
using Unity.Services.Relay;
using Unity.Services.Relay.Models;
using Unity.VisualScripting;
using QueryFilter = Unity.Services.Lobbies.Models.QueryFilter;
using System.Linq;
using Debug = UnityEngine.Debug;
using System.Text.RegularExpressions;
using Task = System.Threading.Tasks.Task;

public class Lobby_VSP : MonoBehaviour
{
    #region InitialStuff

    [SerializeField]
    //private GameObject NetcodeSample;

    public static Lobby_VSP Instance { get; private set; } = null;
    //private NetworkVariableVSP NetcodeSample_Script;
    private Lobby currentLobby;
    private string currentLobbyID = "";
    private bool isPrivate = false;
    private bool canHostReconnect = false;
    private string NewHostID = "-1";
    private int maxPlayers = 8;
    private string newLobbyName = "My Room::" + Guid.NewGuid();
    private int ReactivateLobby_Time = 10; // Lobby will be auto disconnect after 30 seconds 

    private List<string> ListRemovedLobbyID = new List<string>();
    private UnityTransport _transport;
    private const string JoinCodeKey = "null";
    private string _playerId = "null";

    Player loggedInPlayer = new Player();
    private string maxLimitNumber = "9999999"; //Rank,Limit must under this number : RankLimit , LevelLimit if not set RankLimit, LevelLimit when create Lobby
    private List<Lobby> foundLobbies;
    private GameObject MacroLobby_VSP;
    private Relay_VSP MacroRelay_VSP;

    private string RoomPassword = "-1";
    private string RoomCode = "null";
    private string RoomName = "null";
    private string RoomID = "null";
    private bool isLeaving = false;
    

    private List<LobbyInfo_VSP> CurrentLobby_VSP;
    private LobbyInfo_VSP tempLobbyInfo_ = new LobbyInfo_VSP();


    public bool GetCanHostReconnect()
    {
        return canHostReconnect;
    }
    public void SetCanHostReconnect(bool Bool_)
    {
        canHostReconnect = Bool_;
    }
    public int GetHeartBeatTime()
    {
        return ReactivateLobby_Time;
    }
    public void isLeavingPressed(bool Bool_)
    {
        isLeaving = Bool_;
    }

    public void ResetBlackList()
    {
        List<string> newBlackList = new List<string>();
        ListRemovedLobbyID = newBlackList;
    }
    public bool GetIsLeavingPressed()
    {
        return isLeaving;
    }
    public string getPlayerID()
    {
        return _playerId;
    }
    private void Awake()
    {
        
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        DontDestroyOnLoad(gameObject);
        
        _transport = FindObjectOfType<UnityTransport>();
        MacroLobby_VSP = FindObjectOfType<Lobby_VSP>().gameObject;
        if (FindObjectOfType<Relay_VSP>() != null)
        {
            MacroRelay_VSP = FindObjectOfType<Relay_VSP>().gameObject.GetComponent<Relay_VSP>();
        }
        this._playerId = "null";
        //waiting for Authenticate
    }

    public async Task Authenticate()
    {
        await UnityServices.InitializeAsync();

        loggedInPlayer = await GetPlayerFromAnonymousLoginAsync();
        // This data will be included in a lobby under players -> player.data
        loggedInPlayer.Data.Add("Ready", new PlayerDataObject(PlayerDataObject.VisibilityOptions.Member, "No"));


        _playerId = AuthenticationService.Instance.PlayerId;

        if (_playerId != "null")
        {
            if (MacroRelay_VSP != null)
            {
                MacroRelay_VSP.setPlayerIDfromLobby(_playerId); //give MacroNetcode PlayerID for disconnect Player callback
            }

           // NetcodeSample_Script = NetcodeSample.GetComponent<NetworkVariableVSP>();
            CustomEvent.Trigger(MacroLobby_VSP, "SignInDoneTrigger");

            Application.wantsToQuit += Application_wantsToQuit;
        }

    }

    private bool Application_wantsToQuit()
    {
        try
        {
            //bool canQuit = !checkSignedIn();
            if (checkSignedIn())
            {
                StartCoroutine(LeaveBeforeQuit(currentLobby.Id, _playerId));
            }
            return true;
        }
        catch
        {
            return true;
        }
        
    }
    IEnumerator LeaveBeforeQuit(string lobbyId, string playerId)
    {
        isClosing = true;
        yield return new WaitForSeconds(1f);
        Application.Quit();
    }
    
    static async Task<Player> GetPlayerFromAnonymousLoginAsync()
    {
        if (!AuthenticationService.Instance.IsSignedIn)
        {
            // Use Unity Authentication to log in
            await AuthenticationService.Instance.SignInAnonymouslyAsync();

            if (!AuthenticationService.Instance.IsSignedIn)
            {
                throw new InvalidOperationException("Player can not sign in !");
            }
        }

        // Player objects have Get-only properties, so you need to initialize the data bag here if you want to use it
        return new Player(AuthenticationService.Instance.PlayerId, null, data: new Dictionary<string, PlayerDataObject>());
    }

    //.. Coding by Unity No Code | Leo N
    private IEnumerator HeartbeatLobbyCoroutine(string lobbyId, float waitTimeSeconds)
    {
        var delay = new WaitForSecondsRealtime(waitTimeSeconds);

        while (true)
        {
            //Debug.Log("Lobby Heartbeating");
            Lobbies.Instance.SendHeartbeatPingAsync(lobbyId);
            //CustomEvent.Trigger(MacroLobby_VSP, "LobbyHeartbeat_Working");
            yield return delay;
        }
    }
        
    private void UpdateCurrentLobby()
    {
        /*
        LobbyService.Instance.UpdateLobbyAsync(
                lobbyId: currentLobby.Id,
                options: new UpdateLobbyOptions()
                {
                    IsLocked = true
                });
        */
    }

    private int LobbyLimitTime = 60;
    public void SetLobbyLimitTime(int time_)
    {
        LobbyLimitTime = time_;
    }
    public int GetLobbyLimitTime()
    {
        return LobbyLimitTime;
    }
    public void SetHearbeatTime(int time_)
    {
        if (time_ > 29 || time_ < 1)
        {
            Debug.Log("It should be less than 30 seconds");
            return;
        }
        ReactivateLobby_Time = time_;
        Debug.Log("Lobby Heartbeat new delay time : " + time_ + " seconds");
    }
    public void setMaxPlayer(int number)
    {
        maxPlayers = number;
    }
    public void setMaxLimitNumber(int number)
    {
        maxLimitNumber = number.ToString();
    }

    public void setLobbyName(string name)
    {
        newLobbyName = name + "::" + Guid.NewGuid();
    }

    public string GetCreatedRoomName()
    {
        return RoomName;
    }
    public string GetCreatedRoomCode()
    {
        return RoomCode;
    }
    public string GetCreatedRoomID()
    {
        return RoomID;
    }
    public bool GetCreatedRoomPrivate()
    {
        return isPrivate;
    }
    public string GetCreatedRoomPassword()
    {
        return currentLobby.Data["LobbyPassword"].Value;
    }
    public bool checkSignedIn()
    {
        if (_playerId == "null")
        {
            return false;
        }
        else
        {
            return true;
        }

    }
    #endregion

    #region CreateSearch

    #region CreateInitialVar
    private string Setup_LobbyName = "-1";
    private int Setup_LobbyMaxPlayer = 8;
    private bool Setup_LobbyCanHostReconnect = false;

    public bool isHostCanReconnect()
    {
        return Setup_LobbyCanHostReconnect;
    }
    private string FormatNewStringReplaceVSP(string Original_)
    {
        string newString_ = "";
        string FormatChars = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM0123456789_";
        for (int i = 0; i < Original_.Length; i++)
        {
            string listChar_each = Original_[i].ToString();
            if (FormatChars.IndexOf(listChar_each) >= 0) 
            {
                newString_ = newString_ + listChar_each;
            }
            
        }
        return newString_;
    }
    #endregion
    public async void CreateRoom(string Setup_roomName, string Setup_Region, int Setup_maxPlayer, string Setup_Password, bool Setup_Private, string gameMode, int Rank, int RankLimit, int Level, int LevelLimit, int extraLimit, bool Setup_HostReconnect, bool Setup_isLocked)
    {
        if (checkSignedIn() == false)
        {
            Debug.Log("Must Sign In first.");
            return;
        }
        try 
        {
            if (Setup_roomName != "-1") { Setup_roomName = FormatNewStringReplaceVSP(Setup_roomName); }
            if (Setup_Region != "-1") { Setup_Region = FormatNewStringReplaceVSP(Setup_Region); }
            if (Setup_Password != "-1") { Setup_Password = FormatNewStringReplaceVSP(Setup_Password); }
            if (gameMode != "-1") { gameMode = FormatNewStringReplaceVSP(gameMode); }

            if (Setup_maxPlayer < 2)
            {
                Debug.Log("Max Players : must be at least 2!");
                return;
            }
            if (Setup_roomName != "-1")
            {
                if (Setup_roomName.Length < 4)
                {
                    Debug.Log("Lobby name must be at least 4 letters");
                    return;
                }
            }


            //save for New Host create lobby
            //..
            Setup_LobbyName = Setup_roomName;
            Setup_LobbyMaxPlayer = Setup_maxPlayer;
            Setup_LobbyCanHostReconnect = Setup_HostReconnect;
            //End..

            //.. create Room with Relay and get JoinCode

            Allocation a;

            a = await RelayService.Instance.CreateAllocationAsync(Setup_maxPlayer);

            //a = await RelayService.Instance.CreateAllocationAsync(Setup_maxPlayer);
            var joinCode = await RelayService.Instance.GetJoinCodeAsync(a.AllocationId);

            var lobbyData = new Dictionary<string, DataObject>()
            {
                ["JoinCodeKey"] = new DataObject(DataObject.VisibilityOptions.Public, joinCode),
                ["HostID"] = new DataObject(DataObject.VisibilityOptions.Public, "" + _playerId),
                ["Members"] = new DataObject(DataObject.VisibilityOptions.Public, "" + _playerId),
                ["Clients"] = new DataObject(DataObject.VisibilityOptions.Public, "0"),

                ["Slots"] = new DataObject(DataObject.VisibilityOptions.Public, "" + (Setup_maxPlayer - 1).ToString(), DataObject.IndexOptions.S5),
                ["ClientsConnected"] = new DataObject(DataObject.VisibilityOptions.Public, "0"),
                ["LobbyPassword"] = new DataObject(DataObject.VisibilityOptions.Public, "-1"),
                ["LobbyName"] = new DataObject(DataObject.VisibilityOptions.Public, "" + Setup_roomName, DataObject.IndexOptions.S4),
                ["CanHostReconnect"] = new DataObject(DataObject.VisibilityOptions.Public, "" + Setup_HostReconnect.ToString()),
                ["Region"] = new DataObject(DataObject.VisibilityOptions.Public, "" + Setup_Region, DataObject.IndexOptions.S1),
                ["IsLocked"] = new DataObject(DataObject.VisibilityOptions.Public, "" + Setup_isLocked.ToString(), DataObject.IndexOptions.S2),
                ["GameMode"] = new DataObject(DataObject.VisibilityOptions.Public, gameMode, DataObject.IndexOptions.S3),
                ["IsPrivate"] = new DataObject(DataObject.VisibilityOptions.Public, "False"),


                ["Rank"] = new DataObject(DataObject.VisibilityOptions.Public, "" + Rank.ToString(), DataObject.IndexOptions.N1),
                ["RankLimit"] = new DataObject(DataObject.VisibilityOptions.Public, "" + RankLimit.ToString(), DataObject.IndexOptions.N2),
                ["Level"] = new DataObject(DataObject.VisibilityOptions.Public, "" + Level.ToString(), DataObject.IndexOptions.N3),
                ["LevelLimit"] = new DataObject(DataObject.VisibilityOptions.Public, "" + LevelLimit.ToString(), DataObject.IndexOptions.N4),
                ["ExtraNumber"] = new DataObject(DataObject.VisibilityOptions.Public, "" + extraLimit.ToString(), DataObject.IndexOptions.N5),

                //["ExtraLimit"] = new DataObject(DataObject.VisibilityOptions.Public, extraLimit.ToString(), DataObject.IndexOptions.N5),  //must above this number to join in : might be Kills, Score .... depend on your purpose
            };

            if (Setup_Password != "-1")
            {
                if (Setup_Password.Length < 8)
                {
                    Debug.Log("Password length must be 8 or greater ");
                    return;
                }
                else
                {
                    lobbyData["LobbyPassword"] = new DataObject(DataObject.VisibilityOptions.Public, Setup_Password);

                    currentLobby = await LobbyService.Instance.CreateLobbyAsync(
                    lobbyName: Setup_roomName,
                    maxPlayers: Setup_maxPlayer,
                    options: new CreateLobbyOptions()
                    {
                        Data = lobbyData,
                        Password = Setup_Password,
                    });
                }
            }
            else
            {
                currentLobby = await LobbyService.Instance.CreateLobbyAsync(
                lobbyName: Setup_roomName,
                maxPlayers: Setup_maxPlayer,
                options: new CreateLobbyOptions()
                {
                    Data = lobbyData
                });
            }

            RoomCode = currentLobby.LobbyCode;
            RoomName = currentLobby.Name;
            RoomID = currentLobby.Id;

            coroutineHeartbeat = HeartbeatLobbyCoroutine(currentLobby.Id, ReactivateLobby_Time);
            StartCoroutine(coroutineHeartbeat);

            //start connect Relay
            _transport.SetHostRelayData(a.RelayServer.IpV4, (ushort)a.RelayServer.Port, a.AllocationIdBytes, a.Key, a.ConnectionData);

            currentLobbyID = currentLobby.Id;
            //Start Host
            NetworkManager.Singleton.StartHost();

            CustomEvent.Trigger(MacroLobby_VSP, "RoomCreatedDone");
        }
        catch {
            CustomEvent.Trigger(MacroLobby_VSP, "RoomCreatedDone_Error");
        }
        
    }
    
    public async void SearchRoom(int TotalResult_, string Setup_Name, string Setup_Region, string GameMode_, string Rank_, string Level_, string ExtraLimit_, bool SortByNew_, bool Setup_Lock)
    {
        if (checkSignedIn() == false)
        {
            Debug.Log("Must Sign In first.");
            return;
        }

        if (Setup_Name != "-1") { Setup_Name = FormatNewStringReplaceVSP(Setup_Name); }
        if (Setup_Region != "-1") { Setup_Region = FormatNewStringReplaceVSP(Setup_Region); }
        if (GameMode_ != "-1") { GameMode_ = FormatNewStringReplaceVSP(GameMode_); }

        
        try
        {
            foundLobbies = new List<Lobby>();
            
            List<QueryFilter> queryFilters = new List<QueryFilter>
            {
                // Let's search for games with open slots (AvailableSlots greater than 0)
                new QueryFilter(
                    field: QueryFilter.FieldOptions.S5, //Slots > 0
                    op: QueryFilter.OpOptions.GT,
                    value: "0"),
                //s2: isLocked
                new QueryFilter(
                    field: QueryFilter.FieldOptions.S2,
                    op: QueryFilter.OpOptions.EQ,
                    value: ""+ Setup_Lock.ToString())
            };

            if (Setup_Name != "-1")
            {
                queryFilters.Add(new QueryFilter(
                        field: QueryFilter.FieldOptions.S4, // S4 = "LobbyName"
                        op: QueryFilter.OpOptions.EQ,
                        value: Setup_Name));
            }

            if (Setup_Region != "-1")
            {
                queryFilters.Add(new QueryFilter(
                    field: QueryFilter.FieldOptions.S1, // S1 = "Region"
                    op: QueryFilter.OpOptions.EQ,
                    value: Setup_Region));
            }

            
            if (GameMode_ != "-1")
            {
                queryFilters.Add(new QueryFilter(
                    field: QueryFilter.FieldOptions.S3, // S1 = "GameMode"
                    op: QueryFilter.OpOptions.EQ,
                    value: GameMode_));
            }


            //Add Filter Rank
            if (Rank_ != "-1")
            {
                queryFilters.Add(new QueryFilter(
                    field: QueryFilter.FieldOptions.N1, // N1 = "Rank"
                    op: QueryFilter.OpOptions.LE,
                    value: Rank_));

                queryFilters.Add(new QueryFilter(
                    field: QueryFilter.FieldOptions.N2, // N2 = "RankLimit"
                    op: QueryFilter.OpOptions.GE,
                    value: Rank_));

                Debug.Log("Add Rank :" + Rank_);
            }


            //Add Filter Level
            if (Level_ != "-1")
            {
                queryFilters.Add(new QueryFilter(
                    field: QueryFilter.FieldOptions.N3, // N3 = "Level"
                    op: QueryFilter.OpOptions.LE,
                    value: Level_));

                queryFilters.Add(new QueryFilter(
                    field: QueryFilter.FieldOptions.N4, // N4 = "LevelLimit"
                    op: QueryFilter.OpOptions.GE,
                    value: Level_));
            }

            //Add Filter ExtraLimit
            if (ExtraLimit_ != "-1")
            {
                queryFilters.Add(new QueryFilter(
                    field: QueryFilter.FieldOptions.N5, // N5 = "ExtraLimit"
                    op: QueryFilter.OpOptions.LE,
                    value: ExtraLimit_));
            }

            //...searching
            List<QueryOrder> queryOrdering = new List<QueryOrder>
            {
            };

            if (SortByNew_ == true)
            {
                queryOrdering.Add(new QueryOrder(asc: false, QueryOrder.FieldOptions.Created));
            }
            else
            {
                queryOrdering.Add(new QueryOrder(asc: true, QueryOrder.FieldOptions.Created));
            }


            // Call the Query API
            QueryResponse response = await LobbyService.Instance.QueryLobbiesAsync(new QueryLobbiesOptions()
            {
                Count = TotalResult_, // Override default number of results to return
                //Count = 50,
                Filters = queryFilters,
                Order = queryOrdering,
            });

            foundLobbies = response.Results;
            
            
            //BlackList
            
            if (ListRemovedLobbyID.Count > 0 && foundLobbies.Count > 0)
            {
                List<Lobby> NewLobbies_ = new List<Lobby>();
                foreach (var eachItem_ in foundLobbies)
                {
                    string checkingID_ = eachItem_.Id;
                    bool removeIt_ = false;
                    foreach(var eachID_ in ListRemovedLobbyID)
                    {
                        if (checkingID_ == eachID_)
                        {
                            removeIt_ = true;
                            break;
                        }
                    }

                    if (removeIt_ == false)
                    {
                        NewLobbies_.Add(eachItem_);
                    }
                }
                foundLobbies = NewLobbies_;
            }
            
            ConvertToLobbyListVSP();
            CustomEvent.Trigger(MacroLobby_VSP, "SearchLobbyDone", CurrentLobby_VSP);
        }
        catch (Exception ex)
        {
            Debug.Log("Error Search Room : \n" + ex);
        }
    }
    public void ConvertToLobbyListVSP()
    {
        List<LobbyInfo_VSP> newLobby_VSP = new List<LobbyInfo_VSP>();
        int length_ = foundLobbies.Count;


        length_ = foundLobbies.Count;
        for (int i = 0; i < length_; i++)
        {
            var currentLobby_ = foundLobbies[i];
            LobbyInfo_VSP aLobby_VSP = new LobbyInfo_VSP();

            var DataLobbyMembers = ConvertListMembersID(currentLobby_.Data["Members"].Value);
            var DataLobbyClients = ConvertListClientsID(currentLobby_.Data["Clients"].Value);
            var DataLobby_ClientsConnected = ConvertListClientsConnected(currentLobby_.Data["ClientsConnected"].Value);
            var DataLobbyPassword = currentLobby_.Data["LobbyPassword"].Value;
            var DataSearch_GameMode = currentLobby_.Data["GameMode"].Value;
            var DataSearch_Rank = currentLobby_.Data["Rank"].Value;
            var DataSearch_RankLimit = currentLobby_.Data["RankLimit"].Value;
            var DataSearch_Level = currentLobby_.Data["Level"].Value;
            var DataSearch_LevelLimit = currentLobby_.Data["LevelLimit"].Value;
            var DataSearch_ExtraNumber = currentLobby_.Data["ExtraNumber"].Value;
            var DataSearch_Region = currentLobby_.Data["Region"].Value;
            var DataSearch_IsPrivate = currentLobby_.Data["IsPrivate"].Value;
            var DataSearch_IsLocked = currentLobby_.Data["IsLocked"].Value;
            var DataSearch_LobbyName = currentLobby_.Data["LobbyName"].Value;
            var DataSearch_CanHostReconnect = currentLobby_.Data["CanHostReconnect"].Value;

            var DataSearch_Slots = currentLobby_.Data["Slots"].Value;
            aLobby_VSP.AvailableSlots = int.Parse(DataSearch_Slots);

            aLobby_VSP.Id = currentLobby_.Id;
            aLobby_VSP.HostId = currentLobby_.HostId;
            aLobby_VSP.MaxPlayers = currentLobby_.MaxPlayers;
            aLobby_VSP.IsPrivate = bool.Parse(DataSearch_IsPrivate);
            aLobby_VSP.CanHostReconnect = bool.Parse(DataSearch_CanHostReconnect);
            aLobby_VSP.Members = DataLobbyMembers;
            aLobby_VSP.Clients = DataLobbyClients;
            aLobby_VSP.ClientsConnected = DataLobby_ClientsConnected;
            aLobby_VSP.LobbyPassword = DataLobbyPassword;
            aLobby_VSP.IsLocked = bool.Parse(DataSearch_IsLocked);
            aLobby_VSP.LobbyCode = currentLobby_.LobbyCode;
            aLobby_VSP.Name = DataSearch_LobbyName;
            aLobby_VSP.Region = DataSearch_Region;
            aLobby_VSP.GameMode = DataSearch_GameMode;
            aLobby_VSP.RankMin = DataSearch_Rank;
            aLobby_VSP.RankMax = DataSearch_RankLimit;
            aLobby_VSP.LevelMin = DataSearch_Level;
            aLobby_VSP.LevelMax = DataSearch_LevelLimit;
            aLobby_VSP.ExtraNumber = DataSearch_ExtraNumber;

            newLobby_VSP.Add(aLobby_VSP);
            
        }

        CurrentLobby_VSP = newLobby_VSP;
    }

    #endregion

    #region ReconnectNewHost
    //..reconnect if Host quit
    public void BecomeNewHost(string newLobbyID_)
    {
        var Setup_LobbyName_ = "" + newLobbyID_;
        var Setup_LobbyMaxPlayer_ = Setup_LobbyMaxPlayer;
        CustomEvent.Trigger(MacroLobby_VSP, "BecomeNewHost_CreateLobby", Setup_LobbyName_, Setup_LobbyMaxPlayer);
    }

    #endregion

    #region JoinLobby

    public async void JoinLobbyWithLobbyID(string LobbyID_, string myPassword)
    {
        try
        {
            if (myPassword == "-1")
            {
                currentLobby = await LobbyService.Instance.JoinLobbyByIdAsync(
                lobbyId: LobbyID_ ,
                
                options: new JoinLobbyByIdOptions()
                {
                    //Player = loggedInPlayer
                });
                
            }
            else
            {
                if (myPassword.Length < 8)
                {
                    Debug.Log("Password length must be 8 or greater");
                    return;
                }
                else
                {
                    currentLobby = await LobbyService.Instance.JoinLobbyByIdAsync(
                    lobbyId: LobbyID_,
                    
                    options: new JoinLobbyByIdOptions()
                    {
                        //Player = loggedInPlayer,
                        Password = myPassword
                    });

                }
            }

            if (currentLobby != null)
            {


                var a = await RelayService.Instance.JoinAllocationAsync(currentLobby.Data["JoinCodeKey"].Value);

                SetTransformAsClient(a);

                currentLobbyID = currentLobby.Id;
                
                canHostReconnect = bool.Parse(currentLobby.Data["CanHostReconnect"].Value);
                Setup_LobbyCanHostReconnect = canHostReconnect;

                var ListMembersID = ConvertListMembersID(currentLobby.Data["Members"].Value);
                if(ListMembersID.Count >= 2)
                {
                    NewHostID = ListMembersID[1];
                    
                    CustomEvent.Trigger(MacroLobby_VSP, "OnClient_Save2ndMemberID", NewHostID);
                }
                

                //Start Client
                CustomEvent.Trigger(MacroLobby_VSP, "JoinRoom_ConnectingHost", currentLobby.Id);
                
                isLeaving = false;
                NetworkManager.Singleton.StartClient();
                Debug.Log("Started Client : Connecting to Host ...");

                //CustomEvent.Trigger(MacroLobby_VSP, "JoinRoom_Success", currentLobby.Id);

            }
        }
        catch (Exception ex)
        { 
            //Debug.Log("Lobby : Error Join Lobby : \n" + ex);
            if (ex.ToString().IndexOf("player is already a member of the lobby") >= 0)
            {
                CustomEvent.Trigger(MacroLobby_VSP, "JoinRoom_StillInRoom_Fail");
            }
            else
            {
                CustomEvent.Trigger(MacroLobby_VSP, "JoinRoom_Fail");
            }
            
        }
    }

    public bool GetCanHostReconnectOnly() 
    {
        if (currentLobby == null)
        {
            return false;
        }
        else
        {
            bool value_ = bool.Parse(currentLobby.Data["CanHostReconnect"].Value);
            return value_;
        }
    }

    public async void LeaveLobbyOnly()
    {
        try
        {
            if (currentLobby != null)
            {
                await LobbyService.Instance.RemovePlayerAsync(currentLobby.Id, _playerId);
            }

        }
        catch (Exception ex)
        {
            Debug.Log("Leave Lobby Error : \n" + ex);
        }
    }

    public void AddIDtoBlackList(string ID_)
    {
        ListRemovedLobbyID.Add(ID_);
    }

    #endregion

    #region GetLobbyInfo
    public async void GetInfoAnAvailableLobby(string id_)
    {
        try
        {
            if (checkSignedIn() == false)
            {
                Debug.Log("Must Sign In first.");
                return;
            }
            if (id_.Length < 10)
            {
                Debug.Log("Unavailable ID");
                return;
            }

            var myLobby_ = await LobbyService.Instance.GetLobbyAsync(id_);
            if (myLobby_ == null)
            {
                return;
            }


            LobbyInfo_VSP aLobby_VSP = new LobbyInfo_VSP();
            //List<string> currentPlayerInfo = ConvertToPlayersListVSP(myLobby_.Players);
            var DataLobbyMembers = ConvertListMembersID(myLobby_.Data["Members"].Value);
            var DataLobbyClients = ConvertListClientsID(myLobby_.Data["Clients"].Value);
            var DataLobby_ClientsConnected = ConvertListClientsConnected(myLobby_.Data["ClientsConnected"].Value);

            var DataLobbyPassword = myLobby_.Data["LobbyPassword"].Value;
            var DataSearch_GameMode = myLobby_.Data["GameMode"].Value;
            var DataSearch_Rank = myLobby_.Data["Rank"].Value;
            var DataSearch_RankLimit = myLobby_.Data["RankLimit"].Value;
            var DataSearch_Level = myLobby_.Data["Level"].Value;
            var DataSearch_LevelLimit = myLobby_.Data["LevelLimit"].Value;
            var DataSearch_ExtraNumber = myLobby_.Data["ExtraNumber"].Value;
            var DataSearch_Region = myLobby_.Data["Region"].Value;
            var DataSearch_IsPrivate = myLobby_.Data["IsPrivate"].Value;
            var DataSearch_IsLocked = myLobby_.Data["IsLocked"].Value;
            var DataSearch_LobbyName = myLobby_.Data["LobbyName"].Value;
            var DataSearch_CanHostReconnect = myLobby_.Data["CanHostReconnect"].Value;

            var DataSearch_Slots = myLobby_.Data["Slots"].Value;
            aLobby_VSP.AvailableSlots = int.Parse(DataSearch_Slots);

            aLobby_VSP.Id = myLobby_.Id;
            aLobby_VSP.HostId = myLobby_.HostId;
            aLobby_VSP.MaxPlayers = myLobby_.MaxPlayers;
            aLobby_VSP.IsPrivate = bool.Parse(DataSearch_IsPrivate);
            aLobby_VSP.CanHostReconnect = bool.Parse(DataSearch_CanHostReconnect);
            aLobby_VSP.Members = DataLobbyMembers;
            aLobby_VSP.Clients = DataLobbyClients;
            aLobby_VSP.ClientsConnected = DataLobby_ClientsConnected;
            aLobby_VSP.LobbyPassword = DataLobbyPassword;
            aLobby_VSP.IsLocked = bool.Parse(DataSearch_IsLocked);
            aLobby_VSP.LobbyCode = myLobby_.LobbyCode;
            aLobby_VSP.Name = DataSearch_LobbyName;
            aLobby_VSP.Region = DataSearch_Region;

            aLobby_VSP.GameMode = DataSearch_GameMode;
            aLobby_VSP.RankMin = DataSearch_Rank;
            aLobby_VSP.RankMax = DataSearch_RankLimit;
            aLobby_VSP.LevelMin = DataSearch_Level;
            aLobby_VSP.LevelMax = DataSearch_LevelLimit;
            aLobby_VSP.ExtraNumber = DataSearch_ExtraNumber;

            tempLobbyInfo_ = aLobby_VSP;

            CustomEvent.Trigger(MacroLobby_VSP, "InfoALobbyTrigger");
        }
        catch
        {
            //Debug.Log("Get Info Lobby error: \n" + ex.ToString());
            CustomEvent.Trigger(MacroLobby_VSP, "InfoALobbyTrigger_Error");
        }
        
    }
    public string GetCurrentLobbyID()
    {
        if (Variables.Saved.Get("Macro Lobby - Looby ID").ToString() != "-1")
        {
            if (currentLobby != null)
            {
                return currentLobby.Id;
            }
            else
            {
                return "-1";
            }
        }
        else
        {
            return "-1";
        }
        
    }
    public LobbyInfo_VSP GetTempLobbyInfo()
    {

        return tempLobbyInfo_;
    }
    public List<string> ConvertListMembersID(string String_Value)
    {

        List<string> myMembers = new List<string>();
        int count = Regex.Matches(String_Value, ",").Count + 1;
        string m_String = String_Value;
        int check_ = -1;

        for (int i = 0; i < count; i++)
        {
            check_ = m_String.IndexOf(",");
            if (check_ >= 0)
            {
                var aMemberID = m_String.Substring(0, check_);
                myMembers.Add(aMemberID);

                aMemberID = aMemberID + ",";
                m_String = m_String.Replace(aMemberID, "");
            }
            else
            {
                myMembers.Add(m_String);
                break;
            }
        }
        return myMembers;
    }
    public List<string> ConvertListClientsID(string String_Value)
    {

        List<string> myMembers = new List<string>();
        int count = Regex.Matches(String_Value, ",").Count + 1;
        string m_String = String_Value;
        int check_ = -1;

        for (int i = 0; i < count; i++)
        {
            check_ = m_String.IndexOf(",");
            if (check_ >= 0)
            {
                var aMemberID = m_String.Substring(0, check_);
                myMembers.Add(aMemberID);

                aMemberID = aMemberID + ",";
                m_String = m_String.Replace(aMemberID, "");
            }
            else
            {
                myMembers.Add(m_String);
                break;
            }
        }
        return myMembers;
    }
    public List<string> ConvertListClientsConnected(string String_Value)
    {

        List<string> myMembers = new List<string>();
        int count = Regex.Matches(String_Value, ",").Count + 1;
        string m_String = String_Value;
        int check_ = -1;

        for (int i = 0; i < count; i++)
        {
            check_ = m_String.IndexOf(",");
            if (check_ >= 0)
            {
                var aMemberID = m_String.Substring(0, check_);
                myMembers.Add(aMemberID);

                aMemberID = aMemberID + ",";
                m_String = m_String.Replace(aMemberID, "");
            }
            else
            {
                myMembers.Add(m_String);
                break;
            }
        }
        return myMembers;
    }

    #endregion
    
    #region UpdateCLientIDMemberID
    public void AskingUpdateClientIdInALobby(string ClientID, string lobbyPlayerID)
    {
        //NetcodeSample_Script.UnityUpdateClientPrepare(ClientID, lobbyPlayerID);
    }
    public void HostUpdateClientIdInLobby(string ClientID, string lobbyPlayerID)
    {
        try
        {
            Lobby myLobby = currentLobby;
            
            
            string AllClientsID_String = myLobby.Data["Clients"].Value;
            var AllClientsID = ConvertListClientsID(AllClientsID_String);
            string AllClients_new = AllClientsID_String;

            string AllMembers_String = myLobby.Data["Members"].Value;
            var AllMembers = ConvertListMembersID(AllMembers_String);
            var AllMembers_Copy = AllMembers;
            string AllMembers_new = AllMembers_String;

            string AllClientsConnected_String = myLobby.Data["ClientsConnected"].Value;
            var AllClientsConnected = ConvertListClientsConnected(AllClientsConnected_String);
            string AllClientsConnected_new = AllClientsConnected_String;

            int Slots_ = int.Parse(myLobby.Data["Slots"].Value);

            bool update_yes = false;
            if (AllMembers.Count > 0)
            {
                bool existed = false;


                foreach (var memberDataId in AllMembers)
                {
                    if (memberDataId == lobbyPlayerID)
                    {
                        existed = true;
                        
                        break;
                    }
                }

                if (existed == false)
                {
                    update_yes = true;
                    //Debug.Log("Updating Client ... " + AllClientsConnected_new);
                    AllMembers_new = AllMembers_String + "," + lobbyPlayerID;
                    AllClientsConnected_new = AllClientsConnected_new + "," + "1";
                    Slots_ = Slots_ - 1;
                    if (Slots_ < 0)
                    {
                        Slots_ = 0;
                    }
                }

                if (update_yes == true)
                {
                    currentLobby.Data["Members"] = new DataObject(DataObject.VisibilityOptions.Public, AllMembers_new);
                    currentLobby.Data["ClientsConnected"] = new DataObject(DataObject.VisibilityOptions.Public, AllClientsConnected_new);
                    currentLobby.Data["Slots"] = new DataObject(DataObject.VisibilityOptions.Public, Slots_.ToString(), DataObject.IndexOptions.S5);

                    AllClientsConnected = ConvertListClientsConnected(AllClientsConnected_new);
                    for (int i = 0; i < AllClientsConnected.Count; i++)
                    {
                        if (i>0 && AllClientsConnected[i] == "1")
                        {
                            var AllMembersList = ConvertListMembersID(AllMembers_new);
                            CustomEvent.Trigger(MacroLobby_VSP, "OnHost_UpdateSubHost", AllMembersList[i]);
                            break;
                        }
                    }
                }
            }
            else
            {
                return;
            }


            AllMembers = ConvertListMembersID(AllMembers_new);
            AllMembers_new = AllMembers_String;

            int index_ = -1;

            
            foreach (var member in AllMembers)
            {

                index_++;
                if (member == lobbyPlayerID)
                {
                    break;
                }
            }
            
            if (index_ > 0)
            {
                if (index_ >= AllClientsID.Count)
                {
                    AllClients_new = AllClientsID_String + "," + ClientID;
                }
                else
                {
                    AllClientsID[index_] = ClientID;
                    string AllClients_new_new = "0";

                    int j = -1;
                    foreach (var clientid_temp in AllClientsID)
                    {
                        j++;
                        if (j > 0)
                        {
                            AllClients_new_new = AllClients_new_new + "," + clientid_temp;
                        }

                    }
                    AllClients_new = AllClients_new_new;
                }

                currentLobby.Data["Clients"] = new DataObject(DataObject.VisibilityOptions.Public, AllClients_new);
            }

            //for reconnect issue
            LobbyInfo_VSP aLobby_VSP = new LobbyInfo_VSP();
            var DataLobbyMembers = ConvertListMembersID(currentLobby.Data["Members"].Value);
            var DataLobbyClients = ConvertListClientsID(currentLobby.Data["Clients"].Value);
            var DataLobby_ClientsConnected = ConvertListClientsConnected(currentLobby.Data["ClientsConnected"].Value);

            aLobby_VSP.Members = DataLobbyMembers;
            aLobby_VSP.Clients = DataLobbyClients;
            aLobby_VSP.ClientsConnected = DataLobby_ClientsConnected;


            tempLobbyInfo_ = aLobby_VSP;

            CustomEvent.Trigger(MacroLobby_VSP, "WaitToUpdateDataLobby_Trigger");
            
        }

        catch (Exception e)
        {
            Debug.Log("Host Update Client Id error: \n" + e.ToString());
        }
    }

    private void RemovePlayerFromLobbyData(string clientID_)
    {
        try
        {
            Lobby myLobby = currentLobby;


            string AllClientsID_String = myLobby.Data["Clients"].Value;
            var AllClientsID = ConvertListClientsID(AllClientsID_String);
            string AllClients_new = AllClientsID_String;

            string AllMembers_String = myLobby.Data["Members"].Value;
            var AllMembers = ConvertListMembersID(AllMembers_String);
            string AllMembers_new = AllMembers_String;

            string AllClientsConnected_String = myLobby.Data["ClientsConnected"].Value;
            var AllClientsConnected = ConvertListClientsConnected(AllClientsConnected_String);
            string AllClientsConnected_new = AllClientsConnected_String;

            int Slots_ = int.Parse(myLobby.Data["Slots"].Value);
            int MaxPlayer_Value = myLobby.MaxPlayers;

            bool foundID_ = false;
            int index_ = -1;
            if (AllMembers.Count > 0)
            {
                foreach (var memberDataId in AllMembers)
                {
                    index_++;
                    if (memberDataId == clientID_)
                    {
                        foundID_ = true;
                        break;
                    }
                }


                if (foundID_ == true)
                {
                    AllMembers.RemoveAt(index_);
                    AllClientsID.RemoveAt(index_);
                    AllClientsConnected.RemoveAt(index_); // ..

                    Slots_ = Slots_ + 1;
                    if (Slots_ > MaxPlayer_Value)
                    {
                        Slots_ = MaxPlayer_Value;
                    }

                    string new_AllMembers = "";
                    string new_AllClients = "";
                    string new_AllClientsConnected = "";

                    int i = 0;
                    foreach (var memberItem_ in AllMembers)
                    {
                        if (i > 0)
                        {
                            new_AllMembers = new_AllMembers + "," + memberItem_.ToString();
                        }
                        else
                        {
                            new_AllMembers = memberItem_.ToString();
                        }
                        i++;
                    }

                    i = 0;
                    foreach (var clientItem_ in AllClientsID)
                    {
                        if (i > 0)
                        {
                            new_AllClients = new_AllClients + "," + clientItem_.ToString();
                        }
                        else
                        {
                            new_AllClients = clientItem_.ToString();
                        }
                        i++;
                    }

                    i = 0;
                    foreach (var clientItem_Connected in AllClientsConnected)
                    {
                        if (i > 0)
                        {
                            new_AllClientsConnected = new_AllClientsConnected + "," + clientItem_Connected.ToString();
                        }
                        else
                        {
                            new_AllClientsConnected = clientItem_Connected.ToString();
                        }
                        i++;
                    }

                    currentLobby.Data["Members"] = new DataObject(DataObject.VisibilityOptions.Public, new_AllMembers);
                    currentLobby.Data["Clients"] = new DataObject(DataObject.VisibilityOptions.Public, new_AllClients);
                    currentLobby.Data["ClientsConnected"] = new DataObject(DataObject.VisibilityOptions.Public, new_AllClientsConnected);
                    currentLobby.Data["Slots"] = new DataObject(DataObject.VisibilityOptions.Public, Slots_.ToString(), DataObject.IndexOptions.S5);
                   


                    for (i = 0; i < AllClientsConnected.Count; i++)
                    {
                        if (i > 0 && AllClientsConnected[i] == "1")
                        {
                            CustomEvent.Trigger(MacroLobby_VSP, "OnHost_UpdateSubHost", AllMembers[i]);
                            break;
                        }
                    }

                    //for reconnect issue
                    LobbyInfo_VSP aLobby_VSP = new LobbyInfo_VSP();
                    var DataLobbyMembers = ConvertListMembersID(currentLobby.Data["Members"].Value);
                    var DataLobbyClients = ConvertListClientsID(currentLobby.Data["Clients"].Value);
                    var DataLobby_ClientsConnected = ConvertListClientsConnected(currentLobby.Data["ClientsConnected"].Value);

                    aLobby_VSP.Members = DataLobbyMembers;
                    aLobby_VSP.Clients = DataLobbyClients;
                    aLobby_VSP.ClientsConnected = DataLobby_ClientsConnected;


                    tempLobbyInfo_ = aLobby_VSP;
                    //..

                    CustomEvent.Trigger(MacroLobby_VSP, "WaitToUpdateDataLobby_Trigger");
                }
            }
            else
            {
                return;
            }

            

        }

        catch (Exception e)
        {
            Debug.Log("Remove Player error: \n" + e.ToString());
        }
    }
    public async void WaitToUpdateDataLobby()
    {
        try 
        {
            if (currentLobby == null)
            {
                return;
            }

            if (Variables.Saved.Get("Macro Lobby - Looby ID").ToString() == "-1")
            {
                return;
            }
            var myLobby_ = await LobbyService.Instance.UpdateLobbyAsync(
                lobbyId: currentLobby.Id,
                options: new UpdateLobbyOptions()
                {
                    Data = currentLobby.Data,
                    //IsLocked = bool.Parse(currentLobby.Data["IsLocked"].Value),
                });


            if (myLobby_ == null)
            {
                return;
            }


            LobbyInfo_VSP aLobby_VSP = new LobbyInfo_VSP();
            //List<string> currentPlayerInfo = ConvertToPlayersListVSP(myLobby_.Players);
            var DataLobbyMembers = ConvertListMembersID(myLobby_.Data["Members"].Value);
            var DataLobbyClients = ConvertListClientsID(myLobby_.Data["Clients"].Value);
            var DataLobby_ClientsConnected = ConvertListClientsConnected(myLobby_.Data["ClientsConnected"].Value);
            var DataLobbyPassword = myLobby_.Data["LobbyPassword"].Value;
            var DataSearch_GameMode = myLobby_.Data["GameMode"].Value;
            var DataSearch_Rank = myLobby_.Data["Rank"].Value;
            var DataSearch_RankLimit = myLobby_.Data["RankLimit"].Value;
            var DataSearch_Level = myLobby_.Data["Level"].Value;
            var DataSearch_LevelLimit = myLobby_.Data["LevelLimit"].Value;
            var DataSearch_ExtraNumber = myLobby_.Data["ExtraNumber"].Value;
            var DataSearch_Region = myLobby_.Data["Region"].Value;
            var DataSearch_IsPrivate = myLobby_.Data["IsPrivate"].Value;
            var DataSearch_IsLocked = myLobby_.Data["IsLocked"].Value;
            var DataSearch_LobbyName = myLobby_.Data["LobbyName"].Value;
            var DataSearch_CanHostReconnect = myLobby_.Data["CanHostReconnect"].Value;

            var DataSearch_Slots = myLobby_.Data["Slots"].Value;
            aLobby_VSP.AvailableSlots = int.Parse(DataSearch_Slots);

            aLobby_VSP.Id = myLobby_.Id;
            aLobby_VSP.HostId = myLobby_.HostId;
            aLobby_VSP.MaxPlayers = myLobby_.MaxPlayers;
            aLobby_VSP.IsPrivate = bool.Parse(DataSearch_IsPrivate);
            aLobby_VSP.CanHostReconnect = bool.Parse(DataSearch_CanHostReconnect);
            aLobby_VSP.Members = DataLobbyMembers;
            aLobby_VSP.Clients = DataLobbyClients;
            aLobby_VSP.ClientsConnected = DataLobby_ClientsConnected;
            aLobby_VSP.LobbyPassword = DataLobbyPassword;
            aLobby_VSP.IsLocked = bool.Parse(DataSearch_IsLocked);
            aLobby_VSP.LobbyCode = myLobby_.LobbyCode;
            aLobby_VSP.Name = DataSearch_LobbyName;
            aLobby_VSP.Region = DataSearch_Region;

            aLobby_VSP.GameMode = DataSearch_GameMode;
            aLobby_VSP.RankMin = DataSearch_Rank;
            aLobby_VSP.RankMax = DataSearch_RankLimit;
            aLobby_VSP.LevelMin = DataSearch_Level;
            aLobby_VSP.LevelMax = DataSearch_LevelLimit;
            aLobby_VSP.ExtraNumber = DataSearch_ExtraNumber;

            tempLobbyInfo_ = aLobby_VSP;
        }
        catch 
        { 
        
        }
        
    }

    public LobbyInfo_VSP GetCurrentALobby()
    {
        return tempLobbyInfo_;
    }
    #endregion

    #region Others


    public List<string> ConvertToPlayersListVSP(List<Player> Players_)
    {
        List<string> newPlayers_VSP = new List<string>();
        int length_ = Players_.Count;

        for (int i = 0; i < length_; i++)
        {
            var currentPlayer_ = Players_[i];

            newPlayers_VSP.Add(currentPlayer_.Id);
        }
        return newPlayers_VSP;
    }
    
    
    //..
    //.. END Join Lobby as Client

    public void ResetCurrentLobby()
    {
        try
        {
            currentLobby = null;
        }
        catch (Exception e)
        {
            Debug.Log("Error : \n " + e);
        }
        
    }
    public async void ForceDeleteLobby(string id_)
    {
        try
        {
            await Lobbies.Instance.DeleteLobbyAsync(id_);
            Debug.Log("Lobby is deleted ");
            CustomEvent.Trigger(MacroLobby_VSP, "ForceDeleteRoom_Success");
        }
        catch (Exception e)
        {
            Debug.Log("This Lobby is failed to delete : \n " +e);
            CustomEvent.Trigger(MacroLobby_VSP, "ForceDeleteRoom_Fail");
        }
        
    }

    public async void RemoveCurrentPlayerOutOfLobby()
    {
        //must use to remove Player when Host quit
        try
        {
            if (currentLobby != null)
            {
                await LobbyService.Instance.RemovePlayerAsync(currentLobby.Id, _playerId);
                CustomEvent.Trigger(MacroLobby_VSP, "AskResetLobby_Success");
                //currentLobby = null;
            }


        }
        catch
        {
            //Debug.Log("Client Exit Lobby error : \n " + e);
        }
        
    }
    public async void RemovePlayerOutOfLastLobby(string LobbyID_)
    {
        try
        {
            if (currentLobby != null)
            {
                await LobbyService.Instance.RemovePlayerAsync(LobbyID_, _playerId);
                //currentLobby = null;
            }

        }
        catch
        {
        }
    }

    public async void KickClientFromLobby(string clientID_)
    {
        try
        {
            if (checkSignedIn() == false)
            {
                Debug.Log("Must Sign In first.");
                return;
            }

            if (currentLobby == null)
            {
                Debug.Log("You not in any Game Room.");
                return;
            }

            if (currentLobby.HostId == _playerId )
            {
                if (_playerId != clientID_)
                {
                    RemovePlayerFromLobbyData(clientID_);
                    await Lobbies.Instance.RemovePlayerAsync(currentLobby.Id, clientID_);

                    CustomEvent.Trigger(MacroLobby_VSP, "KickClient_Success");
                }
                
            }
            else
            {
                Debug.Log("You are not Host.");
            }

        }
        catch
        {
            //Debug.Log($"Kick Client error: {e}");
        }
    }
    
    public void LockAnyLobby(string aLobby_id)
    {
        //removing
    }
    private void SetTransformAsClient(JoinAllocation a)
    {
        _transport.SetClientRelayData(a.RelayServer.IpV4, (ushort)a.RelayServer.Port, a.AllocationIdBytes, a.Key, a.ConnectionData, a.HostConnectionData);
    }

    
    public bool isAHostOfLobby()
    {
        if (currentLobby != null)
        {
            if (currentLobby.HostId == _playerId)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        return false;

    }
    #endregion

    #region BodyStuff
    //..
    //..Reconnect Lobby and Relay
    public string checkPlayerAlreadyInLobby()
    {
        foreach (var aLobby_ in foundLobbies)
        {
            List<Player> Players_ = aLobby_.Players;
            foreach (var aPlayer_ in Players_)
            {
                if (aPlayer_.Id == _playerId)
                {
                    return aLobby_.Id;
                }
            }
        }
        return "null";
    }



    public void LockCurrentLobby(bool Bool_)
    {
        try
        {
            if (isAHostOfLobby() == false)
            {
                return;
            }
            currentLobby.Data["IsLocked"] = new DataObject(DataObject.VisibilityOptions.Public, "" + Bool_.ToString(), DataObject.IndexOptions.S2);

            CustomEvent.Trigger(MacroLobby_VSP, "WaitToUpdateDataLobby_Trigger");
            CustomEvent.Trigger(MacroLobby_VSP, "LockLobbyDoneTrigger");
        }
        catch (Exception e)
        {
            Debug.Log("Lobby Lock Current Lobby : " + e);
        }

    }

    public async void GetLobbyHostID()
    {
        var newLobby = await LobbyService.Instance.GetLobbyAsync(currentLobby.Id);

        Debug.Log("HostID :" + newLobby.HostId);
    }
    public async void GetLobbyHostName()
    {
        var newLobby = await LobbyService.Instance.GetLobbyAsync(currentLobby.Id);
        Debug.Log("Lobby Name :" + newLobby.Name);
    }

    private IEnumerator coroutineHeartbeat;
    public void StopHeartBeatLobby()
    {
        StopCoroutine(coroutineHeartbeat);
        //StopAllCoroutines();
    }

    public async void CheckIsMemberOfRoom(string lobbyID_)
    {
        try
        {
            var myLobby_ = await LobbyService.Instance.GetLobbyAsync(lobbyID_);

            if (myLobby_ != null)
            {
                bool isMember_ = false;
                List<Player> allPlayers_ = myLobby_.Players;
                foreach (Player player in allPlayers_)
                {
                    if (player.Id == _playerId)
                    {
                        isMember_ = true;
                        break;
                    }
                }

                if (isMember_ == true)
                {
                    if (myLobby_.IsLocked == true)
                    {
                        CustomEvent.Trigger(MacroLobby_VSP, "Member_TrueAMember");
                    }
                    else
                    {
                        CustomEvent.Trigger(MacroLobby_VSP, "Member_TrueNotLockedLobby");
                    }

                }
                else
                {
                    CustomEvent.Trigger(MacroLobby_VSP, "Member_NotAMember");
                }
            }
            else
            {
                CustomEvent.Trigger(MacroLobby_VSP, "Member_RoomNotExist");
            }
        }
        catch (Exception ex)
        {
            if (ex.ToString().IndexOf("Argument should be non-null, non-empty & not only whitespaces.") >= 0)
            {

            }
            else
            {
                if (ex.ToString().IndexOf("lobby not found") >= 0)
                {
                    CustomEvent.Trigger(MacroLobby_VSP, "Member_RoomNotExist");
                }
                else
                {
                    Debug.Log("Lobby : Error Check Member in Lobby : \n" + ex);
                }

            }

        }

    }

    public async void GetCurrentLobbyPlayerIDs()
    {
        try
        {
            currentLobby = await LobbyService.Instance.GetLobbyAsync(currentLobbyID);
            List<string> result = new List<string>();
            foreach (var aPlayer in currentLobby.Players)
            {
                result.Add(aPlayer.Id);
            }

            CustomEvent.Trigger(MacroLobby_VSP, "GetAllPlayerIDsDone", result);
        }
        catch (Exception ex)
        {
            if (ex.ToString().IndexOf("Argument should be non-null, non-empty & not only whitespaces") >= 0)
            {
                //...
            }
            else
            {
                Debug.Log("Lobby : Error Get All PlayerIDs : \n" + ex);
            }

        }


    }

    public bool isLockedCurrentRoom()
    {
        if (currentLobby != null)
        {
            return bool.Parse(currentLobby.Data["IsLocked"].Value);
        }
        else
        {
            return false;
        }

    }
    public async void isLobbyLocked(string lobbyID_)
    {
        try
        {
            var my_currentLobby = await LobbyService.Instance.GetLobbyAsync(lobbyID_);
            if (my_currentLobby != null)
            {
                CustomEvent.Trigger(MacroLobby_VSP, "isLockLobby_result", my_currentLobby.IsLocked);
            }
            else
            {
                CustomEvent.Trigger(MacroLobby_VSP, "isLockLobby_result", false);
            }
        }
        catch
        {
            CustomEvent.Trigger(MacroLobby_VSP, "isLockLobby_result", false);
        }
    }
    //..
    //..End Reconnect
    #endregion

    #region isClosing

    private bool isClosing = false;
 
    public bool GetIsClosing()
    {
        return isClosing;
    }
    public async void LeaveJoinedRoom()
    {
        

        try
        {
            if (checkSignedIn() == false)
            {
                Debug.Log("Must Sign In first.");
                return;
            }

            StopAllCoroutines();
            if (currentLobby == null)
            {
                //Debug.Log("You not in any Game Room.");
                CustomEvent.Trigger(MacroLobby_VSP, "AskLeaveLobby_Success");
                return;
            }

            // todo: Add a check to see if you're host
            if (currentLobby != null)
            {
                if (currentLobby.HostId == _playerId)
                {
                    if (isLeaving == false)
                    {
                        await Lobbies.Instance.DeleteLobbyAsync(currentLobby.Id);
                    }
                    
                    Debug.Log("Host : Deleted Lobby. ");
                    CustomEvent.Trigger(MacroLobby_VSP, "AskResetLobby_Success");
                    currentLobby = null;
                }
                else
                {
                    CustomEvent.Trigger(MacroLobby_VSP, "AskResetLobby_Success");
                    currentLobby = null;
                }
            }
        }
        catch (Exception e)
        {
            Debug.Log($"Error shutting down lobby: {e}");
        }
    }


    private void OnDestroy()
    {
        try
        {
            isClosing = true;
        }
        catch (Exception e)
        {
            Debug.Log("Error : \n " + e);
        }
        
        //RemoveCurrentPlayerOutOfLobby();
    }

    #endregion

    #region PickRegions
    //Regions
    //..
    private string autoSelectRegionName = "auto-select (QoS)";
    private int selectedRegion = -1;
    private List<Region> regions = new List<Region>();
    private List<string> regionOptions = new List<string>();

    public async void OnRegion()
    {
        try
        {
            var allRegions = await RelayService.Instance.ListRegionsAsync();
            regions.Clear();
            regionOptions.Clear();
            foreach (var region in allRegions)
            {
                regionOptions.Add(region.Id);
                regions.Add(region);
            }

            CustomEvent.Trigger(MacroLobby_VSP, "LobbyGetRegion_Done");
        }
        catch (Exception ex)
        {
            Debug.Log("Lobby : Error Get Regions : \n" + ex);
            CustomEvent.Trigger(MacroLobby_VSP, "LobbyGetRegion_Fail");
        }


    }

    public List<Region> getReturnRegions()
    {
        return regions;
    }
    public List<string> getReturnRegionOptions()
    {
        return regionOptions;
    }

    public void SelectRegion(int index)
    {
        if (regions.Count > 1)
        {
            selectedRegion = index;
        }
        else
        {
            selectedRegion = -1;
            Debug.Log("Selecting a Random Region / Location");
        }

    }

    public string GetRegionOrDefault(int index)
    {
        // Return null (indicating to auto-select the region/QoS) if regions list is empty OR auto-select/QoS is chosen
        if (!regions.Any() || index == -1)
        {
            return autoSelectRegionName;
        }
        // else use chosen region (offset -1 in dropdown due to first option being auto-select/QoS)
        return regions[index].Id;
    }
    //..
    //.. END Regions
    #endregion
}


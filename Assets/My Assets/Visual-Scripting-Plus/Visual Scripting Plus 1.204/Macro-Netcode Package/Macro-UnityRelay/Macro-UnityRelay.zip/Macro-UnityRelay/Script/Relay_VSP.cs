using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Unity.Netcode;
using Unity.Netcode.Transports.UTP;
using Unity.Services.Authentication;
using Unity.Services.Core;
using Unity.Services.Relay;
using Unity.Services.Relay.Models;
using Unity.VisualScripting;
using UnityEngine;

public class Relay_VSP : MonoBehaviour
{
    private UnityTransport _transport;
    private GameObject MacroRelay_VSP;
    //private NetcodeVSP MacroNetcode_VSP;

    public static Relay_VSP Instance { get; private set; } = null;
    private int MaxPlayers = 2;
    
    private string playerId = "null";
    private string joinCode = "null";

    public void setMaxPlayer(int number)
    {
        MaxPlayers = number;
    }
    public string getPlayerID()
    {
        return playerId;
    }
    public string getJoinCode()
    {
        return joinCode;
    }
    public void setPlayerIDfromLobby(string id_)
    {
        playerId = id_;
    }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        DontDestroyOnLoad(gameObject);

        _transport = FindObjectOfType<UnityTransport>();
        MacroRelay_VSP = FindObjectOfType<Relay_VSP>().gameObject;
        //MacroNetcode_VSP = FindObjectOfType<NetcodeVSP>().gameObject.GetComponent<NetcodeVSP>();
        this.playerId = "null";
        //waiting for Authenticate
    }
    public async void SignInRelay()
    {
        if (playerId == "null")
        {
            await Authenticate();

            //Done for Authenticate
            playerId = AuthenticationService.Instance.PlayerId;

            //MacroNetcode_VSP.UpdatePlayerID(playerId); //give MacroNetcode PlayerID for disconnect Player callback
            CustomEvent.Trigger(MacroRelay_VSP, "RelaySignInDoneTrigger");
        }
        else
        {
            Debug.Log("Already Signed in");
        }
        
    }
    private static async Task Authenticate()
    {
        await UnityServices.InitializeAsync();
        await AuthenticationService.Instance.SignInAnonymouslyAsync();
    }
    public async void CreateGame()
    {
        if (playerId == "null")
        {
            Debug.Log("Must call [Relay : Sign in] first  !");
            return;
        }

        joinCode = "null";

        Debug.Log("CreateGame");

        try
        {

            string region = GetRegionOrDefault(selectedRegion);
            Debug.Log($"The chosen region is: {region}");
            if (selectedRegion == -1)
            {
                //random region
                Allocation a = await RelayService.Instance.CreateAllocationAsync(MaxPlayers);
                joinCode = await RelayService.Instance.GetJoinCodeAsync(a.AllocationId);
                Debug.Log("Room Code : " + joinCode);
                _transport.SetHostRelayData(a.RelayServer.IpV4, (ushort)a.RelayServer.Port, a.AllocationIdBytes, a.Key, a.ConnectionData);
            }
            else
            {
                Allocation a = await RelayService.Instance.CreateAllocationAsync(MaxPlayers, region);
                joinCode = await RelayService.Instance.GetJoinCodeAsync(a.AllocationId);
                Debug.Log("Room Code : " + joinCode);
                _transport.SetHostRelayData(a.RelayServer.IpV4, (ushort)a.RelayServer.Port, a.AllocationIdBytes, a.Key, a.ConnectionData);

            }
            NetworkManager.Singleton.StartHost();

            CustomEvent.Trigger(MacroRelay_VSP.gameObject, "CreateRoomCode_Done", joinCode);
        }
        catch (Exception ex)
        {
            Debug.Log("Relay : Error Create Game : \n" + ex);
        }

    }

    public async void JoinGame(string joincode)
    {
        if (playerId == "null")
        {
            Debug.Log("Must call [Relay : Sign in] first !");
            return;
        }
        
        Debug.Log("Joining Game");

        try
        {
            JoinAllocation a = await RelayService.Instance.JoinAllocationAsync(joincode);

            _transport.SetClientRelayData(a.RelayServer.IpV4, (ushort)a.RelayServer.Port, a.AllocationIdBytes, a.Key, a.ConnectionData, a.HostConnectionData);

            NetworkManager.Singleton.StartClient();
            CustomEvent.Trigger(MacroRelay_VSP, "RelayJoinInDoneTrigger");
        }
        catch (Exception ex)
        {
            Debug.Log("Relay : Error join with Join Code : \n" + ex);
        }

        
    }



    //Regions

    private string autoSelectRegionName = "auto-select (QoS)";
    private int selectedRegion = -1;
    private List<Region> regions = new List<Region>();
    private List<string> regionOptions = new List<string>();
    
    public async void OnRegion()
    {
        try
        {
            var allRegions = await RelayService.Instance.ListRegionsAsync();
            regions.Clear();
            regionOptions.Clear();
            foreach (var region in allRegions)
            {
                //Debug.Log(region.Id + ": " + region.Description);
                regionOptions.Add(region.Id);
                regions.Add(region);
            }

            CustomEvent.Trigger(MacroRelay_VSP, "RelayGetRegionDoneTrigger");
        }
        catch(Exception ex) 
        {
            Debug.Log("Relay : Error Get Regions : \n" + ex);
            CustomEvent.Trigger(MacroRelay_VSP, "RelayGetRegion_Fail");
        }

        
    }

    public List<Region> getReturnRegions()
    {
        return regions;
    }
    public List<string> getReturnRegionOptions()
    {
        return regionOptions;
    }

    public void SelectRegion(int index)
    {
        if (regions.Count > 1)
        {
            selectedRegion = index;
        }
        else
        {
            selectedRegion = -1;
            Debug.Log("Selecting a Random Region / Location");
        }
        
    }

    public string GetRegionOrDefault(int index)
    {
        // Return null (indicating to auto-select the region/QoS) if regions list is empty OR auto-select/QoS is chosen
        if (!regions.Any() || index == -1)
        {
            return autoSelectRegionName;
        }
        // else use chosen region (offset -1 in dropdown due to first option being auto-select/QoS)
        return regions[index].Id;
    }

    
}

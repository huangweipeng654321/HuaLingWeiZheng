using UnityEngine;
public class EnumIAPProductType : MonoBehaviour
{
    public enum VSP_IAPProductType
    {
        Consumable, //Can not Restored
        NonConsumable, //Can be Restored
        Subscription, //Can be Restored
    };

    public enum VSP_IAPAndroidSubscriptionGroup
    {
        UnknownSubscriptionUpgradeDowngradePolicy,
        ImmediateWithTimeProration,
        ImmediateAndChargeProratedPrice,
        ImmediateWithoutProration,
        Deferred,
        ImmediateAndChargeFullPrice,
    };
}

using UnityEngine;
using UnityEngine.Purchasing;
using UnityEngine.Purchasing.Extension;
using Unity.VisualScripting;
using System.Collections.Generic;
using System;
using Unity.Services.Core;
using UnityEngine.Events;
using System.Linq;
using UnityEngine.UI;
using Product = UnityEngine.Purchasing.Product;


public class SubscriptionGroupAndroid
{
    IStoreController m_StoreController;
    IExtensionProvider m_ExtensionsProvider;

    string[] m_SubscriptionIds;

    GooglePlayProrationMode m_UpgradeSubscriptionProrationMode;
    GooglePlayProrationMode m_DowngradeSubscriptionProrationMode;
    //GameObject m_Obj = GameObject.Find("Macro-InAppPurchase");
    public SubscriptionGroupAndroid(IStoreController storeController, IExtensionProvider extensionsProvider, GooglePlayProrationMode upgradeSubscriptionProrationMode,
        GooglePlayProrationMode downgradeSubscriptionProrationMode, params string[] subscriptionIds)
    {
        m_StoreController = storeController;
        m_UpgradeSubscriptionProrationMode = upgradeSubscriptionProrationMode;
        m_DowngradeSubscriptionProrationMode = downgradeSubscriptionProrationMode;
        m_ExtensionsProvider = extensionsProvider;
        m_SubscriptionIds = subscriptionIds;
    }

    public void BuySubscription(string newSubscriptionId)
    {
        
        //CustomEvent.Trigger(m_Obj, "abc", "Buying Sub123");

        var currentSubscriptionId = CurrentSubscriptionId();
        if (IsASubscriptionChange(currentSubscriptionId, newSubscriptionId))
        {
            ChangeSubscriptionTier(currentSubscriptionId, newSubscriptionId);
        }
        else
        {
            m_StoreController.InitiatePurchase(newSubscriptionId);
        }
    }

    static bool IsASubscriptionChange(string previousSubscriptionId, string newSubscriptionId)
    {
        return previousSubscriptionId != null && previousSubscriptionId != newSubscriptionId;
    }

    void ChangeSubscriptionTier(string currentSubscriptionId, string newSubscriptionId)
    {
        Debug.Log($"Change Subscription from {currentSubscriptionId} to {newSubscriptionId}");
        var prorationMode = (int)DetermineProrationMode(currentSubscriptionId, newSubscriptionId);
        var googlePlayStoreExtension = m_ExtensionsProvider.GetExtension<IGooglePlayStoreExtensions>();
        googlePlayStoreExtension.UpgradeDowngradeSubscription(currentSubscriptionId, newSubscriptionId, prorationMode);
    }

    GooglePlayProrationMode DetermineProrationMode(string previousSubscriptionId, string newSubscriptionId)
    {
        //In this sample, we use different proration modes depending on if the new subscription is an upgrade compared to the current one.
        var isNewSubscriptionAnUpgrade = IsSubscriptionAnUpgrade(previousSubscriptionId, newSubscriptionId);
        return isNewSubscriptionAnUpgrade ? m_UpgradeSubscriptionProrationMode : m_DowngradeSubscriptionProrationMode;
    }

    bool IsSubscriptionAnUpgrade(string currentSubscription, string newSubscription)
    {
        return SubscriptionTier(newSubscription) > SubscriptionTier(currentSubscription);
    }

    int SubscriptionTier(string subscriptionId)
    {
        return Array.IndexOf(m_SubscriptionIds, subscriptionId);
    }

    public string CurrentSubscriptionId()
    {
        return m_SubscriptionIds.FirstOrDefault(IsSubscribedTo);
    }

    bool IsSubscribedTo(string subscriptionId)
    {
        var subscriptionProduct = m_StoreController.products.WithID(subscriptionId);
        if (subscriptionProduct.definition.type != ProductType.Subscription)
        {
            return false;
        }
        return IsSubscribedTo(subscriptionProduct);
    }

    public bool IsSubscribedTo(Product subscription)
    {
        // If the product doesn't have a receipt, then it wasn't purchased and the user is therefore not subscribed.
        if (subscription?.receipt == null)
        {
            return false;
        }

        //..Fake Store
        var receipt = (Dictionary<string, object>)MiniJson.JsonDecode(subscription.receipt);
        var store = receipt["Store"];
        if (store.ToString() == "fake")
        {
            Debug.Log("You're using Fake store : IsSubscribedTo always TRUE");
            return true;
        }
        //..end

        var subscriptionManager = new SubscriptionManager(subscription, null);
        var subscriptionInfo = subscriptionManager.getSubscriptionInfo();

        return subscriptionInfo.isSubscribed() == Result.True;
    }
}
public class SubscriptionGroupIOS
{
    IStoreController m_StoreController;
    IExtensionProvider m_ExtensionsProvider;

    public string[] m_SubscriptionIds;

    public SubscriptionGroupIOS(IStoreController storeController, IExtensionProvider extensionsProvider, params string[] subscriptionIds)
    {
        m_StoreController = storeController;
        m_ExtensionsProvider = extensionsProvider;
        m_SubscriptionIds = subscriptionIds;
    }

    public void BuySubscription(string newSubscriptionId)
    {
        m_StoreController.InitiatePurchase(newSubscriptionId);
    }

    public string CurrentSubscriptionId()
    {
        return m_SubscriptionIds.FirstOrDefault(IsSubscribedToIOS);
    }

    public bool IsSubscribedToIOS(string subscriptionId)
    {
        var subscriptionProductIOS = m_StoreController.products.WithID(subscriptionId);
        return IsSubscribedToIOS(subscriptionProductIOS);
    }

    public static bool IsSubscribedToIOS(Product subscription)
    {
        // If the product doesn't have a receipt, then it wasn't purchased and the user is therefore not subscribed.
        if (subscription?.receipt == null)
        {
            return false;
        }

        //..Fake Store
        var receipt = (Dictionary<string, object>)MiniJson.JsonDecode(subscription.receipt);
        var store = receipt["Store"];
        if (store.ToString() == "fake")
        {
            Debug.Log("You're using Fake store : IsSubscribedTo always TRUE");
            return true;
        }
        //..end

        var subscriptionManager = new SubscriptionManager(subscription, null);
        var subscriptionInfo = subscriptionManager.getSubscriptionInfo();

        return subscriptionInfo.isSubscribed() == Result.True;
    }
}


public class VSP_InAppPurchase : MonoBehaviour, IDetailedStoreListener
{
    string[] group_subscriptionIds;

    public GooglePlayProrationMode upgradeSubscriptionProrationMode = GooglePlayProrationMode.ImmediateAndChargeProratedPrice;
    public GooglePlayProrationMode downgradeSubscriptionProrationMode = GooglePlayProrationMode.Deferred;

    SubscriptionGroupAndroid m_SubscriptionGroupAndroid;
    SubscriptionGroupIOS m_SubscriptionGroupIOS;
    //
    [Header("Test only : 1 = Android | 2 = iOS")]
    public bool Testmode = false;
    public int Platform = 1;

    
    int platform_ = 1; //1:Android , PC . 2: iOS
    class IAPProductList
    {
        public String product_id;
        public int product_type;
    }
    //create Product List
    List<IAPProductList> AllProductList = new List<IAPProductList>();

    IStoreController m_StoreController; // The Unity Purchasing system.
    IExtensionProvider m_extension;
    IAppleExtensions m_AppleExtensions;
    IGooglePlayStoreExtensions m_GooglePlayStoreExtensions;

    bool isIAPInitialized = false;
    bool useUpgradeDowngradeSubscription = false;

    string[] array_subscriptionIds = new string[5];
    int array_subscriptionIds_length = 0;

    [Header("[Read Only]")]
    public UnityEvent OnIAPInitialized_Return;
    public UnityEvent OnIAPinitFailed_Return;

    public UnityEvent OnIAPPurchasedComplete_Return;
    public UnityEvent OnIAPPurchasedFailed_Return;
    public UnityEvent OnIAPPurchasedFailedDetailed_Return;
    public UnityEvent OnIAPNewSubComplete_Return;

    public UnityEvent OnIAPFetchMoreProduct_Complete;
    public UnityEvent OnIAPFetchMoreProduct_Failed;

    public UnityEvent OnRestore_Complete;
    public UnityEvent OnRestore_Failed;
    public UnityEvent OnIAPInitialized_MSG;
    //Subscription on Google Play only

    void Awake()
    {
        if (Application.isMobilePlatform)
        {
            if (Application.platform == RuntimePlatform.Android)
            {
                platform_ = 1;

            }
            else
            {
                platform_ = 2;
            }

        }
        else
        {
            platform_ = 1;
            //For Testing only
            if (Testmode == true)
            {
                platform_ = Platform;
            }
        }


    }

    //setup Proration Mode for up down Subscription Android
    public void SetupProrationMode(string UpgradeMode, string DowngradeMode)
    {
        if (UpgradeMode != "" && DowngradeMode != "")
        {
            if (UpgradeMode == "UnknownSubscriptionUpgradeDowngradePolicy")
            {
                upgradeSubscriptionProrationMode = GooglePlayProrationMode.UnknownSubscriptionUpgradeDowngradePolicy;
            }
            if (UpgradeMode == "ImmediateWithTimeProration")
            {
                upgradeSubscriptionProrationMode = GooglePlayProrationMode.ImmediateWithTimeProration;
            }
            if (UpgradeMode == "ImmediateAndChargeProratedPrice")
            {
                upgradeSubscriptionProrationMode = GooglePlayProrationMode.ImmediateAndChargeProratedPrice;
            }
            if (UpgradeMode == "ImmediateWithoutProration")
            {
                upgradeSubscriptionProrationMode = GooglePlayProrationMode.ImmediateWithoutProration;
            }
            if (UpgradeMode == "Deferred")
            {
                upgradeSubscriptionProrationMode = GooglePlayProrationMode.Deferred;
            }
            if (UpgradeMode == "ImmediateAndChargeFullPrice")
            {
                upgradeSubscriptionProrationMode = GooglePlayProrationMode.ImmediateAndChargeFullPrice;
            }
            //downgrade
            if (DowngradeMode == "UnknownSubscriptionUpgradeDowngradePolicy")
            {
                downgradeSubscriptionProrationMode = GooglePlayProrationMode.UnknownSubscriptionUpgradeDowngradePolicy;
            }
            if (DowngradeMode == "ImmediateWithTimeProration")
            {
                downgradeSubscriptionProrationMode = GooglePlayProrationMode.ImmediateWithTimeProration;
            }
            if (DowngradeMode == "ImmediateAndChargeProratedPrice")
            {
                downgradeSubscriptionProrationMode = GooglePlayProrationMode.ImmediateAndChargeProratedPrice;
            }
            if (DowngradeMode == "ImmediateWithoutProration")
            {
                downgradeSubscriptionProrationMode = GooglePlayProrationMode.ImmediateWithoutProration;
            }
            if (DowngradeMode == "Deferred")
            {
                downgradeSubscriptionProrationMode = GooglePlayProrationMode.Deferred;
            }
            if (DowngradeMode == "ImmediateAndChargeFullPrice")
            {
                downgradeSubscriptionProrationMode = GooglePlayProrationMode.ImmediateAndChargeFullPrice;
            }
        }
    }

    //ss1 Buying Consumable
    //..
    public void InitializePurchasing()
    {
        if (UnityServices.State == ServicesInitializationState.Uninitialized)
        {
            Debug.Log("You need to call Initialize Unity Game Service first !");
            return;
        }
        var builder = ConfigurationBuilder.Instance(StandardPurchasingModule.Instance());

        
        foreach (IAPProductList aIAPProduct in AllProductList)
        {

            var IAPtype_ = ProductType.Consumable;
            var IAPid_ = aIAPProduct.product_id;

            if (aIAPProduct.product_type == 0)
            {
                IAPtype_ = ProductType.Consumable;
            }
            if (aIAPProduct.product_type == 1)
            {
                IAPtype_ = ProductType.NonConsumable;
            }
            if (aIAPProduct.product_type == 2)
            {
                IAPtype_ = ProductType.Subscription;
            }

            builder.AddProduct(IAPid_, IAPtype_);
        }
        
        UnityPurchasing.Initialize(this, builder);
    }

    
    public void OnInitialized(IStoreController controller, IExtensionProvider extensions)
    {
        Debug.Log("In-App Purchasing successfully initialized");
        m_StoreController = controller;
        m_extension = extensions;
        //extension for restoring
        if (platform_ == 2)
        {
            m_AppleExtensions = m_extension.GetExtension<IAppleExtensions>();
        }
        if (platform_ == 1)
        {
            m_GooglePlayStoreExtensions = m_extension.GetExtension<IGooglePlayStoreExtensions>();
        }

        isIAPInitialized = true;


        //Create Sub Group Initial
        if (useUpgradeDowngradeSubscription == true)
        {
            InitialDowngradeUpgradeSubscription(controller, extensions);
        }


        //On Complete in Visual Scripting
        OnIAPInitialized_Return.Invoke();
    }
    public void InitialDowngradeUpgradeSubscription(IStoreController controller, IExtensionProvider extensions)
    {
        var os_ = platform_;

        string[] array_IAP_SubIds = array_subscriptionIds;
        int count_ = array_subscriptionIds_length;

        //get all sub to group
        group_subscriptionIds = new string[count_];

        for (int i = 0; i < count_; i++)
        {
            group_subscriptionIds[i] = array_IAP_SubIds[i];
        }

        //...IOS : purchase normally , Android : with setup of ProrationMode
        if (os_ == 1)
        {
            m_SubscriptionGroupAndroid = new SubscriptionGroupAndroid(controller, extensions, upgradeSubscriptionProrationMode, downgradeSubscriptionProrationMode, group_subscriptionIds);
        }
        else
        {
            m_SubscriptionGroupIOS = new SubscriptionGroupIOS(controller, extensions, group_subscriptionIds);
        }


    }
    public void BuySubscriptionIAP(string newSubscriptionId)
    {
        if (platform_ == 1)
        {
            m_SubscriptionGroupAndroid.BuySubscription(newSubscriptionId);
        }
        else
        {
            m_SubscriptionGroupIOS.BuySubscription(newSubscriptionId);
        }
    }

    void UpdateUI(string subscriptionId)
    {
        //currentSubscriptionText.text = $"Current Subscription: {subscriptionId ?? "None"}";
    }
    public void AddProduct(string id, int type)
    {
        AllProductList.Add(new IAPProductList() { product_id = id, product_type = type });

        //add SubID to Sub Group
        if (type == 2)
        {
            array_subscriptionIds[array_subscriptionIds_length] = id;
            array_subscriptionIds_length++;
            useUpgradeDowngradeSubscription = true;
        }
    }

    public bool isIAPInitializedReturn()
    {
        return isIAPInitialized;
    }

    public void OnInitializeFailed(InitializationFailureReason error)
    {
        OnInitializeFailed(error, null);
        OnIAPinitFailed_Return.Invoke();
    }

    public void OnInitializeFailed(InitializationFailureReason error, string message)
    {
        var errorMessage = $"Purchasing failed to initialize. Reason: {error}.";

        if (message != null)
        {
            errorMessage += $" More details: {message}";
        }

        Debug.Log(errorMessage);
    }


    public void PurchaseOneProduct(string name)
    {
        if (isIAPInitialized == true)
        {

            var currProduct = m_StoreController.products.WithID(name);
            if (currProduct != null)
            {
                foreach (IAPProductList aProduct in AllProductList)
                {
                    if (aProduct.product_id == name)
                    {
                        if (aProduct.product_type == 2)
                        {
                            //purchase Subscription from SubscriptionGroup
                            BuySubscriptionIAP(name);
                        }
                        else
                        {
                            // normal purchase Consume and Non-Consume
                            m_StoreController.InitiatePurchase(name);
                        }
                    }
                }



            }

        }
        else
        {
            Debug.Log("You need to Initialize In-App Purchasing first !");
        }

    }


    public PurchaseProcessingResult ProcessPurchase(PurchaseEventArgs args)
    {
        //Retrieve the purchased product
        var product = args.purchasedProduct;


        Debug.Log($"Purchase Complete - Product: {product.definition.id}");

        //CustomEvent.Trigger(this.gameObject,"On Purchase Complete", product.definition.id);
        Variables.Application.Set("MacroIAP-ProductID", product.definition.id);
        OnIAPPurchasedComplete_Return.Invoke();


        return PurchaseProcessingResult.Complete;
    }

    
    public void OnPurchaseFailed(Product product, PurchaseFailureReason failureReason)
    {
        Debug.Log($"Purchase failed - Product: '{product.definition.id}', PurchaseFailureReason: {failureReason}");

        Variables.Application.Set("MacroIAP-ProductID", product.definition.id);
        Variables.Application.Set("MacroIAP-Error", product.definition.id + " : " + failureReason);
        OnIAPPurchasedFailed_Return.Invoke();
    }

    public void OnPurchaseFailed(Product product, PurchaseFailureDescription failureDescription)
    {
        Debug.Log($"Purchase failed - Product: '{product.definition.id}'," +
            $" Purchase failure reason: {failureDescription.reason}," +
            $" Purchase failure details: {failureDescription.message}");

        Variables.Application.Set("MacroIAP-ProductID", product.definition.id);
        Variables.Application.Set("MacroIAP-Error", product.definition.id + " : " + failureDescription.reason + " : " + failureDescription.message);
        OnIAPPurchasedFailedDetailed_Return.Invoke();
    }
    //2: Subscription
    public bool IsSubscribedTo(string product_id)
    {
        //UnityEngine.Purchasing.Product subscription = null;
        var subscription = m_StoreController.products.WithID(product_id);

        // If the product doesn't have a receipt, then it wasn't purchased and the user is therefore not subscribed.
        if (subscription.receipt == null || subscription == null)
        {
            return false;
        }

        //The intro_json parameter is optional and is only used for the App Store to get introductory information.
        var receipt = (Dictionary<string, object>)MiniJson.JsonDecode(subscription.receipt);
        var store = receipt["Store"];
        if (store.ToString() == "fake")
        {
            Debug.Log("You're using Fake store. It always return True");
            return true;
        }

        var subscriptionManager = new SubscriptionManager(subscription, null);

        // The SubscriptionInfo contains all of the information about the subscription.
        // Find out more: https://docs.unity3d.com/Packages/com.unity.purchasing@3.1/manual/UnityIAPSubscriptionProducts.html
        var info = subscriptionManager.getSubscriptionInfo();

        if (info.isSubscribed() == Result.True)
        {
            return true;
        }

        return false;
    }

    public class SubcriptionMoreInfo
    {
        public String productID;
        public DateTime PurchaseDate;
        public Result isSubscribed; //Unsupported , True, False
        public Result isExpired; //Unsupported , True, False
        public Result isCancelled; //Unsupported , True, False
        public Result isFreeTrial; //Unsupported , True, False
        public Result isAutoRenewing; //Unsupported , True, False
        public TimeSpan getRemainingTime;
        public Result isIntroductoryPricePeriod; //Unsupported , True, False
        public TimeSpan getIntroductoryPricePeriod;
        public long getIntroductoryPricePeriodCycles;
        public string getIntroductoryPrice; //not available , USD, $
        public DateTime getExpireDate;
    }

    public SubcriptionMoreInfo GetSubscriptionInfoMore(string product_id)
    {
        bool existID = false;
        foreach (IAPProductList aProduct_ in AllProductList)
        {
            if (aProduct_.product_id == product_id)
            {
                existID = true;
                break;
            }
        }


        SubcriptionMoreInfo info = new SubcriptionMoreInfo();
        info.productID = product_id;
        info.PurchaseDate = DateTime.Now;
        info.isSubscribed = Result.Unsupported;
        info.isExpired = Result.Unsupported;
        info.isCancelled = Result.Unsupported;
        info.isFreeTrial = Result.Unsupported;
        info.isAutoRenewing = Result.Unsupported;
        info.getRemainingTime = TimeSpan.Zero;
        info.isIntroductoryPricePeriod = Result.Unsupported;
        info.getIntroductoryPricePeriod = TimeSpan.Zero;
        info.getIntroductoryPricePeriodCycles = 0;
        info.getIntroductoryPrice = "$0.99";
        info.getExpireDate = DateTime.Now;

        if (existID == false)
        {
            Debug.Log("Not found Product ID ... showing default Subscription info");
            return info;
        }

        var subscription = m_StoreController.products.WithID(product_id);

        // If the product doesn't have a receipt, then it wasn't purchased and the user is therefore not subscribed.
        if (subscription.receipt == null || subscription == null)
        {
            Debug.Log("Not found purchased Subscription ID: Wrong Product ID or user not purchase any Subscription yet... showing default Subscription info");
            return info;
        }

        //The intro_json parameter is optional and is only used for the App Store to get introductory information.
        var receipt = (Dictionary<string, object>)MiniJson.JsonDecode(subscription.receipt);
        var store = receipt["Store"];
        if (store.ToString() == "fake")
        {
            Debug.Log("You're using Fake store. It always return a default fake Info");
            return info;
        }

        var subscriptionManager = new SubscriptionManager(subscription, null);

        // The SubscriptionInfo contains all of the information about the subscription.
        // Find out more: https://docs.unity3d.com/Packages/com.unity.purchasing@3.1/manual/UnityIAPSubscriptionProducts.html
        var realinfo = subscriptionManager.getSubscriptionInfo();

        info.productID = realinfo.getProductId();
        info.PurchaseDate = realinfo.getPurchaseDate();
        info.isSubscribed = realinfo.isSubscribed();
        info.isExpired = realinfo.isExpired();
        info.isCancelled = realinfo.isCancelled();
        info.isFreeTrial = realinfo.isFreeTrial();
        info.isAutoRenewing = realinfo.isAutoRenewing();
        info.getRemainingTime = realinfo.getRemainingTime();
        info.isIntroductoryPricePeriod = realinfo.isIntroductoryPricePeriod();
        info.getIntroductoryPricePeriod = realinfo.getIntroductoryPricePeriod();
        info.getIntroductoryPricePeriodCycles = realinfo.getIntroductoryPricePeriodCycles();
        info.getIntroductoryPrice = realinfo.getIntroductoryPrice();
        info.getExpireDate = realinfo.getExpireDate();

        return info;
    }

    //3: Fetching more Products
    public void FetchAdditionalProducts(string name, int type)
    {
        if (isIAPInitialized == false)
        {
            return;
        }
        var type_ = ProductType.Consumable;
        if (type == 0)
        {
            type_ = ProductType.Consumable;
        }
        else if (type == 1)
        {
            type_ = ProductType.NonConsumable;
        }
        else if (type == 2)
        {
            type_ = ProductType.Subscription;
        }

        var additionalProductsToFetch = new HashSet<ProductDefinition>
    {
        new ProductDefinition(name, type_)
    };

        Debug.Log($"Fetching additional products in progress");

        m_StoreController.FetchAdditionalProducts(additionalProductsToFetch,
            () =>
            {
                //Additional products fetched, they can now be purchased.
                Debug.Log($"Successfully fetched additional products");
                OnIAPFetchMoreProduct_Complete.Invoke();
            },
            (reason, message) =>
            {
                var errorMessage = $"Fetching additional products failed: {reason.ToString()}.";

                if (message != null)
                {
                    errorMessage += $" More details: {message}";
                }

                Debug.Log(errorMessage);

                Variables.Application.Set("MacroIAP-Error", errorMessage);
                OnIAPFetchMoreProduct_Failed.Invoke();
            });
    }

    public bool isphone()
    {
        return Application.isMobilePlatform;
    }

    //4: Restoring
    public void Restore()
    {
        if (Application.isMobilePlatform == false)
        {

            Debug.Log("Using FAKE store. Always return True");
            List<string> result = new List<string>();
            result.Add("com.mycompany.myproduct.sampleID1");
            result.Add("com.mycompany.myproduct.sampleID2");

            Variables.ActiveScene.Set("IAP_Restore_ListID", result);
            OnRestore_Complete.Invoke();

        }
        else
        {
            if (platform_ == 1)
            {
                m_GooglePlayStoreExtensions.RestoreTransactions(OnRestore);

            }
            else
            {
                m_AppleExtensions.RestoreTransactions(OnRestore);
            }
        }



    }

    void OnRestore(bool success, string error)
    {
        var restoreMessage = "";
        if (success)
        {
            // This does not mean anything was restored,
            // merely that the restoration process succeeded.
            restoreMessage = "Restore Successful";
        }
        else
        {
            // Restoration failed.
            restoreMessage = $"Restore Failed with error: {error}";

            OnRestore_Failed.Invoke();
        }

        Debug.Log(restoreMessage);
    }

    public void HasProduct_Restored()
    {
        //OnRestore might not work... use HasProductReturn to check each ProductID instead of Restore
        //..
        string[] ID_List = new string[32];
        int i = 0;
        foreach (IAPProductList aIAPProduct in AllProductList)
        {
            var exist_Product = m_StoreController.products.WithID(aIAPProduct.product_id);
            if (exist_Product != null && exist_Product.hasReceipt)
            {
                ID_List[i] = aIAPProduct.product_id;
                i++;
            }
        }
        List<string> result = new List<string>();

        for (int count = 0; count < i; count++)
        {
            result.Add(ID_List[count]);
        }

        Variables.ActiveScene.Set("IAP_Restore_ListID", result);
        OnRestore_Complete.Invoke();
    }
    public bool HasProductReturn(string nameID)
    {
        var exist_Product = m_StoreController.products.WithID(nameID);
        if (exist_Product != null && exist_Product.hasReceipt)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    bool IsSubscribedToIAP(Product subscription)
    {
        // If the product doesn't have a receipt, then it wasn't purchased and the user is therefore not subscribed.
        if (subscription?.receipt == null)
        {
            return false;
        }

        //..Fake Store
        var receipt = (Dictionary<string, object>)MiniJson.JsonDecode(subscription.receipt);
        var store = receipt["Store"];
        if (store.ToString() == "fake")
        {
            Debug.Log("You're using Fake store : IsSubscribedTo always TRUE");
            return true;
        }
        //..end

        var subscriptionManager = new SubscriptionManager(subscription, null);
        var subscriptionInfo = subscriptionManager.getSubscriptionInfo();

        return subscriptionInfo.isSubscribed() == Result.True;
    }

    public string CurrentSubscriptionIdIAP()
    {
        string[] array_SubscriptionList = group_subscriptionIds;
        int length_ = array_SubscriptionList.Length;

        string currentID = "none";
        bool checking_ = false;

        for (int i = 0; i < length_; i++)
        {
            string id_ = array_SubscriptionList[i];
            checking_ = IsSubscribedToIAP(m_StoreController.products.WithID(id_));
            if (checking_ == true)
            {
                currentID = id_;
                break;
            }
        }

        return currentID;
        
    }
}

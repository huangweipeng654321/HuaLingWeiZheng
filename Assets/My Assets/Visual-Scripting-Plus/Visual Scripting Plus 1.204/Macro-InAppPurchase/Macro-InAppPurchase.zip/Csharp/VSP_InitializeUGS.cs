using System;
using Unity.Services.Core;
using Unity.Services.Core.Environments;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Events;

public class VSP_InitializeUGS : MonoBehaviour
{
    const string k_Environment = "production";
    public UnityEvent OnSuccessReturn;
    public UnityEvent OnFailedReturn;

    
    public void StartInitializeUGS()
    {
        Initialize(OnSuccess, OnError);
    }
    

    void Awake()
    {
        Initialize(OnSuccess, OnError);
    }
    void Initialize(Action onSuccess, Action<string> onError)
    {
        try
        {
            var options = new InitializationOptions().SetEnvironmentName(k_Environment);

            UnityServices.InitializeAsync(options).ContinueWith(task => onSuccess());
        }
        catch (Exception exception)
        {
            onError(exception.Message);
        }
    }

    void OnSuccess()
    {
        var text = "Congratulations!\nUnity Gaming Services has been successfully initialized.";
        Debug.Log(text);
        OnSuccessReturn.Invoke();
    }

    void OnError(string message)
    {
        var text = $"Unity Gaming Services failed to initialize with error: {message}.";
        Debug.Log(text);
        Variables.Application.Set("MacroIAP-Error", text);
        OnFailedReturn.Invoke();
    }

}

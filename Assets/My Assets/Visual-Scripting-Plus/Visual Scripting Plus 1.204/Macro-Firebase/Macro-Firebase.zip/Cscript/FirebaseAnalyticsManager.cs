
namespace Firebase.Sample.Analytics {
    using Firebase;
    using Firebase.Analytics;
    using Firebase.Extensions;
    using System;
    using System.Collections;
    using UnityEngine;

  // Handler for UI buttons on the scene.  Also performs some
  // necessary setup (initializing the firebase app, etc) on
  // startup.
  public class FirebaseAnalyticsManager : MonoBehaviour {

        DependencyStatus dependencyStatus = DependencyStatus.UnavailableOther;
        protected bool firebaseInitialized = false;

        // When the app starts, check to make sure that we have
        // the required dependencies to use Firebase, and if not,
        // add them if possible.
        private void Start()
        {
            FirebaseInitial();
        }
        public virtual void FirebaseInitial() 
        {
          FirebaseApp.CheckAndFixDependenciesAsync().ContinueWithOnMainThread(task => {
            dependencyStatus = task.Result;
            if (dependencyStatus == DependencyStatus.Available) {
              InitializeFirebase();
            } else {
              Debug.Log("Could not resolve all Firebase dependencies: " + dependencyStatus);
            }
          });
        }

    
        void InitializeFirebase() {
          //DebugLog("Enabling data collection.");
          FirebaseAnalytics.SetAnalyticsCollectionEnabled(true);

         // DebugLog("Set user properties.");
          // Set the user's sign up method.
          FirebaseAnalytics.SetUserProperty(
            FirebaseAnalytics.UserPropertySignUpMethod,
            "Google");
                // Set the user ID.
                string myname = "uber_user_510_"+UnityEngine.Random.Range(0, 99999999);
            

          FirebaseAnalytics.SetUserId(myname);
          // Set default session duration values.
          FirebaseAnalytics.SetSessionTimeoutDuration(new TimeSpan(0, 30, 0));
          firebaseInitialized = true;

            StartCoroutine(AnalyticsLogin());
        }

        IEnumerator AnalyticsLogin() 
        {
            yield return new WaitForSeconds(1);
            FirebaseAnalytics.LogEvent(FirebaseAnalytics.EventLogin);
            //Debug.Log("Login data.");
            StartCoroutine(ResetAnalyticsData());
        }

        // Reset analytics data for this app instance.
        IEnumerator ResetAnalyticsData() 
        {
            yield return new WaitForSeconds(2);
            FirebaseAnalytics.ResetAnalyticsData();
            //Debug.Log("Reset analytics data.");
            Debug.Log("Firebase Analytics is started.");
        }
    
  }
}
